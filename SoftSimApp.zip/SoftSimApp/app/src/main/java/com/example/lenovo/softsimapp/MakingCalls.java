package com.example.lenovo.softsimapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class MakingCalls extends AppCompatActivity {
    EditText edtCallOn,edtReceiveOn;

    String numberTocall = "";
    String reciveOn = "";
    static Context context;
    SharedPreferences pref;
    SharedPreferences.Editor mEditor;
    LocationManager locationManager;
    String callURL;
    List<String> phoneList = new ArrayList<String>();

    String databaseAPIKEY = "686e669fbef4f969515c"; //To be replaced with the key from database 686e669fbef4f969515c

    String lastname="";String firstname="";String email="";String mobile="";String password="";String identity="";
    //String identity="";
    String apikey="25c0f00d96451b2edf5e";
    ClientDB clientDB;
    //Cursor cursor;

    TextView textview2;
    static TableLayout dialpad;
    static LinearLayout call_cont, cont_number, del, cont;
    static String cc = "";
    //static ImageView updown;
    public static EditText phoneNumber;
    IntentFilter filter = new IntentFilter();
    String[] list = new String[C.locales.length];
    public static HashMap<String, String> listH = new HashMap<String, String>();
    public static ArrayList<String> listA = new ArrayList<String>();


    Cursor cursor;
    String APIKEY = "b05a9b6599b7d323ae71";
    Person person;
    String call_num = "";
    Integer counter = 0;
    String phones = "";

    // Defines a tag for identifying log entries
    private static final String tag = "ContactsListActivity";
    //private ContactDetailFragment mContactDetailFragment;
    // If true, this is a larger screen device which fits two panes
    private boolean isTwoPaneLayout;
    private boolean trZeroButton = false;
    // True if this activity instance is a search result view (used on pre-HC devices that load
    // search results in a separate instance of the activity rather than loading results in-line
    // as the query is typed.

    private boolean isSearchResultView = false;
    public static boolean isVerified = true;
    public static boolean AUTH = false;
    public static boolean phonebook = true, ccpopup = false;
    public static Uri curUser = null;
    LinearLayout oView;
    public static String callNow = null;
    public static String phoneGlobal = "";
    public static long resumeBlock = 0l;
    public static long syncBlock = 0l;
    String userDetails = "";
    //EditText phoneNumber;

    ImageView imageview;

    String clientPhonenumber="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_making_calls);

        person = new Person();

        clientPhonenumber = person.getMobile();

        final EditText passText = (EditText) findViewById(R.id.phoneNumber);


        //BIND VIEW ELEMENTS TO JAVA CLASS VARIABLES
        cont = (LinearLayout) findViewById(R.id.cont);
        cont_number = (LinearLayout) findViewById(R.id.cont_number);
        del = (LinearLayout) findViewById(R.id.del);
        phoneNumber = (EditText) findViewById(R.id.phoneNumber);
       // imageview = (ImageView)findViewById(R.id.imageView);

        phoneNumber.setVisibility(View.INVISIBLE);
        //imageview.setVisibility(View.INVISIBLE);

        dialpad = (TableLayout) findViewById(R.id.dialpad);
        call_cont = (LinearLayout) findViewById(R.id.call_cont);
        //updown = (ImageView)findViewById(R.id.updown);

        call(phoneNumber.getText().toString());

        //DIALPAD BUTTON ARRAY
        String[] dialpad_buttons = {"0","1","2","3","4","5","6","7","8","9","0","*","#"};
        int[] dialpad_buttons_ids = {R.id.button0,R.id.button1,R.id.button2,R.id.button3,R
                .id.button4,R.id.button5,R.id.button6,R.id.button7,R.id.button8,R.id.button9,R.id.button0,R.id.buttonstar,R.id.buttonpound};
        //SET CLICK LISTENERS FOR EACH DIALPAD BUTTON
        for(int c=0;c<dialpad_buttons_ids.length;c++){

            ImageButton t = (ImageButton) findViewById(dialpad_buttons_ids[c]);
            t.setTag(dialpad_buttons[c]);
            t.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p) {

                    phoneNumber.setVisibility(View.VISIBLE);
                    imageview.setVisibility(View.VISIBLE);

                    if(trZeroButton){ trZeroButton = false; return; }
                    int sel = phoneNumber.getSelectionStart();
                    //APPEND CHARACTE TO CREATE PHONE NUMBER
                    String s1 = phoneNumber.getText().toString().substring(0, sel);
                    String s2 = phoneNumber.getText().toString().substring(sel, phoneNumber.getText().length());
                    String temp = s1+p.getTag().toString()+s2;

                    //String temp = phoneNumber.getText().toString();
                    //temp+=p.getTag().toString();
                    dialpadPress(temp);
                    //MOVE CURSOR TO AN END
                    phoneNumber.setSelection(sel+1);
                    //phoneNumber.setSelection(phoneNumber.getText().length());
                }});
        }

        //SET LONG CLICK LISTENER FOR PLUS
        ImageButton button0 = (ImageButton) findViewById(R.id.button0);
        button0.setOnLongClickListener(new View.OnLongClickListener(){

            @Override
            public boolean onLongClick(View paramView) {

                int sel = phoneNumber.getSelectionStart();
                trZeroButton = true;
                //APPEND CHARACTE TO CREATE PHONE NUMBER
                String s1 = phoneNumber.getText().toString().substring(0, sel);
                String s2 = phoneNumber.getText().toString().substring(sel, phoneNumber.getText().length());
                String temp = s1+"+"+s2;

                //String temp = phoneNumber.getText().toString();
                //temp+="+";

                dialpadPress(temp);
                //MOVE CURSOR TO AN END OF EDIT TEXT
                //phoneNumber.setSelection(phoneNumber.getText().length());
                phoneNumber.setSelection(sel+1);
                return false;
            }});


        //LONG PRESS COMPLETELY REMOVE PHONE NUMBER FOMR EDIT TEXT
        del.setOnLongClickListener(new View.OnLongClickListener(){

            @Override
            public boolean onLongClick(View paramView) {

                //C.log("ggg", "LOJNG PRESSEDE");
                dialpadPress("");
                return true;
            }});


        //ANDROID BUG - DISABLE KEYBOARD POPUP WITH ANY METHOD..
        //phoneNumber.setInputType(0);
        phoneNumber.setLongClickable(false);
        disableSoftInputFromAppearing(phoneNumber);

        //phoneNumber.setKeyListener(null);
        // Check if two pane bool is set based on resource directories
        isTwoPaneLayout = getResources().getBoolean(R.bool.has_two_panes);

        // }

        //listH = new HashMap<String, String>();
        //listA = new ArrayList<String>();


    }

    public static void disableSoftInputFromAppearing(EditText editText) {
        if (Build.VERSION.SDK_INT >= 11) {
            editText.setRawInputType(InputType.TYPE_CLASS_TEXT);
            editText.setTextIsSelectable(true);
        } else {
            editText.setRawInputType(InputType.TYPE_NULL);
            editText.setFocusable(true);
        }
    }

    //START ASYNC TIMER IN LOOP TO CHECK EMAIL VERIFICATION ON SERVER - WORKS ONLY WHEN MAIN SCREEN OF zvonivru IS ACTIVE
    private boolean trVerBlock = false;
    final Handler h = new Handler();
    public static AlertDialog dialog;

    public void dialpadPress(String c){
        //TODO
        phoneNumber.setText(c);

    }    //ONLY SLIDE UP DIALPAD - this method is invoked from contact_list_fragment.xml
    public void showDialpadUp(View v){


        dialpad = (TableLayout) findViewById(R.id.dialpad);
        //SHOW IF NOT VISIBLE
        if(dialpad.getVisibility()!=View.VISIBLE){

            dialpad.setVisibility(View.VISIBLE);
            //updown.setImageDrawable(getResources().getDrawable(R.drawable.ic_down));
        }
    }

    //DEL CHARACTER
    public void delChar(View v){

        String temp = phoneNumber.getText().toString();
        if(temp.length()>0){

            int sel = phoneNumber.getSelectionStart();
            //APPEND CHARACTE TO CREATE PHONE NUMBER
            if(sel>0){
                String s1 = phoneNumber.getText().toString().substring(0, sel-1);
                String s2 = phoneNumber.getText().toString().substring(sel, phoneNumber.getText().length());
                String temp2 = s1+s2;

                //String temp = phoneNumber.getText().toString();
                //temp+=p.getTag().toString();
                dialpadPress(temp2);
                //MOVE CURSOR TO AN END
                phoneNumber.setSelection(sel-1);

                //phoneNumber.setText(temp2.substring(0, temp2.length()-1));
                //MOVE CURSOR TO AN END OF EDIT TEXT
                //phoneNumber.setSelection(phoneNumber.getText().length());
            }
        }
    }


    //LISTENER FOR CALL NOW BUTTON
    public void call_now(View v){

        if(phoneNumber.getText().toString().length()==0){

            Toast.makeText(context,"Please provide valid number", Toast.LENGTH_SHORT).show();
        }else{

            cursor = clientDB.getData();


            if(cursor.moveToFirst()) {

               //firstname = cursor.getString(1);
               // lastname = cursor.getString(2);
               // identity = cursor.getString(3);
                //password = cursor.getString(4);
                //email = cursor.getString(5);
                mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);

                apikey = cursor.getString(7);
                //cursor.moveToNext();

            }
            callURL = "https://greydotapi.me/?par1="+mobile+"&par2="+phoneNumber.getText().toString()+"&k=526c915430f835fa19c1"+"&do="+8;

            android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

            builder.create();
            builder.setTitle("Connecting...");
            builder.setMessage(mobile+" : Please answer incooming call to initiate softSIM call To: " + phoneNumber.getText().toString());
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub

                     startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(callURL)));



                    AsyncHttpClient client = new AsyncHttpClient();
                    client.get(callURL,  new AsyncHttpResponseHandler() {
                        @Override
                        public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {


                            android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

                            builder.create();
                            builder.setTitle("Connecting");
                            builder.setMessage("Please answer incomming call on: " + mobile+"\nTo initiate softSIM calling to: " + phoneNumber.getText().toString());
                            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // TODO Auto-generated method stub


                                }
                            });

                            android.support.v7.app.AlertDialog alert = builder.create();

                            alert.show();
                        }

                        @Override
                        public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {



                            android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

                            builder.create();
                            builder.setTitle("Connection Failed");
                            builder.setMessage("Please check your balance or internet connection and try again");
                            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // TODO Auto-generated method stub


                                }
                            });

                            android.support.v7.app.AlertDialog alert = builder.create();

                            alert.show();
                        }
                    });




                }
            });

            android.support.v7.app.AlertDialog alert = builder.create();

            alert.show();
            phonebook = false;
            callNowL();



        }



    }

    //CALL NOW LOCAL METHOD
   public void callNowL(){

        //if(!isVerified){notVerified();}else{call(phoneNumber.getText().toString());}
        call(phoneNumber.getText().toString());
    }

    //CALL METHOD
    public void call(String phone){

        callNow = null;
        String phoneOr = phone;
        //если начинается на 8 заменяешь на 8 на +7
        if(phone.startsWith("8") && phone.length()>10) phone = "+7" + phone.substring(1, phone.length());

        //CHECK IF VALID OR NOT
        if(phone.length()>0){

            //PERFORM CALL

            //Toast.makeText(getApplicationContext(), phone, Toast.LENGTH_LONG).show();
            //INSERT CALL RECORD
            String description = "call";
            String from = "Я";
            String to = phoneOr;
            String duration = "0.00";
            String deb = "0.00";
            String cre = "0.00";
            String country = "US";
            Integer type = 4;

            DataBaseAdapter db = new DataBaseAdapter(context);
            db.open();
            db.insertReport(System.currentTimeMillis(), description, from, to, duration, 0f, country, Integer.valueOf(type));
            db.close();
            //PREPARE CALL INTENT
            // Intent callIntent = new Intent(Intent.ACTION_CALL);
            //C.log("Call Parser", Uri.parse("tel:"+(pref.getString("IVR_"+cc.toUpperCase(), "+37125415609")+"*")+phone).toString());
            //callIntent.setData(Uri.parse("tel:"+phone));
            cursor = clientDB.getData();


            if(cursor.moveToFirst()) {

               // firstname = cursor.getString(1);
                //lastname = cursor.getString(2);
               // identity = cursor.getString(3);
               // password = cursor.getString(4);
               // email = cursor.getString(5);
                mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);
               // apikey = cursor.getString(7);
                //cursor.moveToNext();

            }


            //startActivity(callIntent);//databaseAPIKEY   1ea9a91f6f53558d9203
            callURL = "https://greydotapi.me/?par1="+mobile+"&par2="+phoneNumber.getText().toString()+"&k=526c915430f835fa19c1"+"&do="+8;

            AsyncHttpClient client = new AsyncHttpClient();
            client.get(callURL,  new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {


                    android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

                    builder.create();
                    builder.setTitle("Connecting");
                    builder.setMessage(mobile+" : Please answer in coming call to initiate softSIM call To: " + phoneNumber.getText().toString());
                    builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub


                        }
                    });

                    android.support.v7.app.AlertDialog alert = builder.create();

                    alert.show();
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {



                    android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

                    builder.create();
                    builder.setTitle("Connection Failed");
                    builder.setMessage("Please Try Again");
                    builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub


                        }
                    });

                    android.support.v7.app.AlertDialog alert = builder.create();

                    alert.show();
                }
            });

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(callURL)));
            android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

            builder.create();
            builder.setTitle("Connecting...");
            builder.setMessage(mobile+" : Please answer incooming call to initiate softSIM call To: " + phoneNumber.getText().toString());
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub

                     startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(callURL)));








                }
            });

            //android.support.v7.app.AlertDialog alert = builder.create();

           // alert.show();




        }else{

           // badPhonePopup(this, phoneOr, R.string.number2);
        }
    }

    public  void calling(View view)
    {
        cursor = clientDB.getData();


        if(cursor.moveToFirst()) {

            firstname = cursor.getString(1);
            lastname = cursor.getString(2);
            identity = cursor.getString(3);
            password = cursor.getString(4);
            email = cursor.getString(5);
            mobile = cursor.getString(6);
            //password = cursor.getString(5);
            //identity = cursor.getString(6);
            apikey = cursor.getString(7);
            cursor.moveToNext();

        }
        //molepoapi =25c0f00d96451b2edf5e
        callURL = "https://greydotapi.me/?par1="+mobile+"&par2="+phoneNumber.getText().toString()+"&k=526c915430f835fa19c1"+"&do="+8;

        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

        builder.create();
        builder.setTitle("Connecting...");
        builder.setMessage(mobile+" : Please answer incooming call to initiate softSIM call To: " + phoneNumber.getText().toString());
        builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub

               startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(callURL)));



                AsyncHttpClient client = new AsyncHttpClient();
                client.get(callURL,  new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {


                        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

                        builder.create();
                        builder.setTitle("Connecting");
                        builder.setMessage("Please answer incomming call on: " + mobile+"\nTo initiate softSIM calling to: " + phoneNumber.getText().toString());
                        builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub


                            }
                        });

                        android.support.v7.app.AlertDialog alert = builder.create();

                        alert.show();
                    }

                    @Override
                    public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {



                        android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(MakingCalls.this);

                        builder.create();
                        builder.setTitle("Connection Failed");
                        builder.setMessage("Please Try Again");
                        builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub


                            }
                        });

                        android.support.v7.app.AlertDialog alert = builder.create();

                        alert.show();
                    }
                });




            }
        });

        android.support.v7.app.AlertDialog alert = builder.create();

        alert.show();


    }

}
