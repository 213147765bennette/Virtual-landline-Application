package com.example.lenovo.softsimapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class VerifyingPhonenumber extends AppCompatActivity {

    EditText edtNumber,edtCode;
    String number = "";
   // String userCode;
    String codeSent;

    Button btn12,getVerificationCode,btn13;

    private FirebaseAuth.AuthStateListener mAuthListener;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifying_phonenumber);

        edtNumber = findViewById(R.id.editText);
        edtCode = findViewById(R.id.editText4);
        //userCode = edtCode.getText().toString();
        number = edtNumber.getText().toString();

        btn12 = findViewById(R.id.button12);
        btn13 = findViewById(R.id.button13);
        getVerificationCode = findViewById(R.id.getVerificationCode);

        btn13.setVisibility(View.INVISIBLE);

        btn12.setEnabled(false);
        btn12.setBackgroundColor(getResources().getColor(R.color.maru));
        getVerificationCode.setBackgroundColor(getResources().getColor(R.color.maru));
        btn13.setBackgroundColor(getResources().getColor(R.color.maru));

        mAuth = FirebaseAuth.getInstance();

    }

    /**public void verifyingNumber(View view)
    {
        Intent intent = new Intent(this,SoftSimHome.class);
        startActivity(intent);
    }*/
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(),"The code is correct",Toast.LENGTH_LONG).show();

                           // btn13.setVisibility(View.VISIBLE);
                            Intent intent = new Intent(VerifyingPhonenumber.this,SoftSimSignup.class);
                            intent.putExtra("mobile",number);
                            startActivity(intent);

                        } else {

                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {

                                Toast.makeText(getApplicationContext(),"The code is incorrect, please use the correct code",Toast.LENGTH_LONG).show();

                            }
                        }
                    }
                });
    }

    private void sendVerificationCode()
    {
        number = edtNumber.getText().toString();

        if (number.isEmpty())
        {
            edtNumber.setError("Phone number is required");
            edtNumber.requestFocus();
            return;

        }

        if (number.length() < 10)
        {
            edtNumber.setError("Phone number is required");
            edtNumber.requestFocus();
            return;
        }

        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                number,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks

    }

    private void verifyReceivedCode()
    {

        String userCode = edtCode.getText().toString();
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(codeSent, userCode);
        signInWithPhoneAuthCredential(credential);

    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

        }

        @Override
        public void onVerificationFailed(FirebaseException e) {

        }


        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);

            codeSent = s;
        }
    };



    public void verifyingNumber(View view)
    {
        sendVerificationCode();

        btn12.setEnabled(true);
    }

    public  void verifyCodeEnter(View view)
    {


            verifyReceivedCode();


    }

   public void nextSignupPage(View view)
    {

        Intent intent = new Intent(this,SoftSimSignup.class);
        intent.putExtra("mobile",number);
        startActivity(intent);
    }
}
