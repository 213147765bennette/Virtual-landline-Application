package com.example.lenovo.softsimapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TableLayout;
import android.widget.TextView;

import org.w3c.dom.Element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class AboutUs extends AppCompatActivity {
    TextView textView1,textView2,textView3;
    EditText edtCallOn,edtReceiveOn,phoneNumber;

    String numberTocall = "";
    String reciveOn = "";
    SharedPreferences pref;
    SharedPreferences.Editor mEditor;
    LocationManager locationManager;

    List<String> phoneList = new ArrayList<String>();


    TextView textview2;

    static String cc = "";
    //static ImageView updown;

    IntentFilter filter = new IntentFilter();
    String[] list = new String[C.locales.length];
    public static HashMap<String, String> listH = new HashMap<String, String>();
    public static ArrayList<String> listA = new ArrayList<String>();

    Person person;
    String call_num = "";


    // Defines a tag for identifying log entries
    private static final String tag = "ContactsListActivity";
    //private ContactDetailFragment mContactDetailFragment;
    // If true, this is a larger screen device which fits two panes
    private boolean isTwoPaneLayout;
    private boolean trZeroButton = false;
    // True if this activity instance is a search result view (used on pre-HC devices that load
    // search results in a separate instance of the activity rather than loading results in-line
    // as the query is typed.

    private boolean isSearchResultView = false;
    public static boolean isVerified = true;
    public static boolean AUTH = false;
    public static boolean phonebook = true, ccpopup = false;
    public static Uri curUser = null;
    LinearLayout oView;
    public static String callNow = null;
    public static String phoneGlobal = "";
    public static long resumeBlock = 0l;
    public static long syncBlock = 0l;
    String userDetails = "";
    //EditText phoneNumber;

    ImageView imageview;

    String clientPhonenumber="";
    Element element2;

    EditText etData,edtnumberToCall;
    Button btn;
    String callURL;
    static Context context;
    //List<String> phoneList = new ArrayList<String>();
    static TableLayout dialpad;

    static LinearLayout call_cont, cont_number, del, cont;
    ArrayList<String> StoreContacts ;
    ArrayAdapter<String> arrayAdapter ;

    String myphonename, phonenumber ;
    public  static final int RequestPermissionCode  = 1;
    String databaseAPIKEY = ""; //"686e669fbef4f969515c"To be replaced with the key from database 686e669fbef4f969515c

    private String LOG_TAG = "XML";
    private int UpdateFlag = 0;
    String Name="";
    String Range ="";
    ArrayList<String> urls=new ArrayList<String>();
    //String myXmlString = "<name>Bennette Lesetja Molepo</name>";

    String myResponse = "";
    TextView txtString;
    ImageView imageView;

    String callingnumber = "";
    String name="";
    //String phoneNumber="";
    long id = 0;
    //String apikey = "";//"1ea9a91f6f53558d9203";//7dd8621c007eafa8e935//TO BE REPLACED BY THE ONE FROM CLIENT DATABASE 686e669fbef4f969515c
    ListView myListView;
    //Cursor cursor;

    private static final int REQUEST_READ_CONTACTS = 444;
    private ListView mListView;
    private ProgressDialog pDialog;
    private Handler updateBarHandler;
    ArrayList<String> contactList;
    Cursor cursor;
    ListView listView;

    int counter;
    String maruURL = "https://clientarea.maru.africa/cart.php?a=add&pid=24";
    // maruURL = "https://clientarea.maru.africa/cart.php?a=add&pid=24";
    // public String url = "https://greydotapi.me/?k=686e669fbef4f969515c&do=5";
    String newClientAPIKey = "";
    String clientMobile="";
    ClientDB clientDB;
    SimpleCursorAdapter adapter;
    String fileAPI = "";
    String[] from;
    int[] to;

    String lastname="";String firstname="";String email="";String mobile="";String password="";String identity="";
    //String identity="";
    String apikey="";
    SearchView searchView;
    String phones = "";
    public String url= "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.ic_launcher);

        clientDB = new ClientDB(this);

    }


    void run() throws IOException {
        url = "https://greydotapi.me/?k=1ea9a91f6f53558d9203"+"&do=5";
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                myResponse  = response.body().string();

                AboutUs.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        //txtString.setText(myResponse);


                    }
                });


            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.aboutusmenu
                , menu);

        return true;
    }

    MenuItem searchMenuItem;
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_addcontact) {

            Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            startActivity(intent);
            return true;

        }else  if (id == R.id.topup) {

            Intent intent = new Intent(AboutUs.this,TopUp.class);
            startActivity(intent);

            // topup();

            return true;
        }else  if (id == R.id.history) {
            Intent intent = new Intent(AboutUs.this,CallHistory.class);
            startActivity(intent);
            return true;
        }else  if (id == R.id.ClientDetails) {

            cursor = clientDB.getData();


            if(cursor.moveToFirst())
            {



                //int DBid = cursor.getInt(0);
                firstname = cursor.getString(1);
                lastname = cursor.getString(2);
                identity = cursor.getString(3);
                password = cursor.getString(4);
                email = cursor.getString(5);
                mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);
                apikey = cursor.getString(7);


                //int DBid = cursor.getInt(0);
                /** firstname = cursor.getString(1);
                 lastname = cursor.getString(2);
                 email = cursor.getString(3);
                 mobile = cursor.getString(4);
                 //password = cursor.getString(5);
                 //identity = cursor.getString(6);
                 apikey = cursor.getString(5);*/

                // String name,String surname,String username,String password,String email,String phone ,String clientApi

                /**String firstname = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_NAME));
                 String lastname = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_SURNAME));
                 String email = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_EMAIL));
                 String mobile = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_PHONE));
                 String password = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_PASSWORD));
                 String identity = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_PASSWORD));
                 String apikey = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_APPKEY));
                 */

            }
            AlertDialog.Builder builder = new AlertDialog.Builder(AboutUs.this);

            builder.create();
            builder.setTitle("Client details");
            builder.setMessage("Fisrt name: "+firstname+"\nLast name: "+lastname+"\nEmail: "+email+"\nMobile: "
                    +mobile+"\nPassword: " +password+" "+"\nIdentity: " +identity+" "+"\nApi Key: " + apikey);
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub


                }
            });

            AlertDialog alert = builder.create();

            alert.show();

            return true;
        }/**else  if (id == R.id.Aboutus) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.maru.africa")));
            Intent intent = new Intent(AboutUs.this,AboutUs.class);
            startActivity(intent);
            return true;
        }*/else  if (id == R.id.Help) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maru.bitrix24.com/online/clientchannel")));
            //https://maru.bitrix24.com/online/clientchannel

            Intent intent = new Intent(AboutUs.this,Help.class);
            startActivity(intent);

            return true;
        }



        return super.onOptionsItemSelected(item);
    }




    public void sendsms(View view)
    {
        Intent intent = new Intent(AboutUs.this,SendingSMS.class);
        intent.putExtra("phone",phones);
        startActivity(intent);
    }
    public void makesCallings(View view)
    {
        Intent intent = new Intent(AboutUs.this,SoftSimHome.class);
        startActivity(intent);
    }
    public void conectionss(View view)
    {
        Intent intent = new Intent(AboutUs.this,ConnectFriends.class);
        startActivity(intent);
    }
}
