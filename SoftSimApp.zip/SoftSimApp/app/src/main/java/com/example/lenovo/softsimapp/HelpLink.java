package com.example.lenovo.softsimapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

public class HelpLink extends AppCompatActivity {

    ProgressDialog progressDialog;
    WebView myWebView;
    String phones="";
    String maruURL = "https://clientarea.maru.africa/cart.php?a=add&pid=24";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_link);

        progressDialog  = new ProgressDialog(HelpLink.this);

        progressDialog.setTitle("Directing page...");
        progressDialog.setMessage("Please wait while we load our help site");
        progressDialog.show();

        myWebView = (WebView) findViewById(R.id.activity_main_webview);
       // WebSettings webSettings = myWebView.getSettings();



        AsyncHttpClient asycnHttpClient = new AsyncHttpClient(true, 80, 443);
        // AsyncHttpClient client = new AsyncHttpClient();
        asycnHttpClient.get(maruURL, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                progressDialog.dismiss();

                myWebView.loadUrl(maruURL);

                /**  AlertDialog.Builder builder = new AlertDialog.Builder(HelpLink.this);

                  builder.create();
                  builder.setTitle("Sending sms...");
                  builder.setMessage("Your SMS has been sent to: "+textPhoneNo.getText().toString());
                  builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          // TODO Auto-generated method stub


                      }
                  });

                  AlertDialog alert = builder.create();

                  alert.show();*/

            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                progressDialog.dismiss();

                /**AlertDialog.Builder builder = new AlertDialog.Builder(SendingSMS.this);

                builder.create();
                builder.setTitle("Failed to send sms");
                builder.setMessage("Please check your internet connection and try again");
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub


                    }
                });

                AlertDialog alert = builder.create();

                alert.show();*/
            }


        });

        myWebView.setWebViewClient(new WebViewClient());
    }

    public void aboutsSMS(View view)
    {
        Intent intent = new Intent(HelpLink.this,SendingSMS.class);
        intent.putExtra("phone",phones);
        startActivity(intent);
    }
    public void makesCallings(View view)
    {
        Intent intent = new Intent(HelpLink.this,SoftSimHome.class);
        startActivity(intent);
    }
    public void conectionss(View view)
    {
        Intent intent = new Intent(HelpLink.this,ConnectFriends.class);
        startActivity(intent);
    }
}
