package com.example.lenovo.softsimapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TopUpActivity extends AppCompatActivity {
    EditText edtText;
    String userInput="";

    String maruURL = "https://clientarea.maru.africa/cart.php?a=add&pid=24";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_up);
        edtText = (EditText) findViewById(R.id.editText);

        userInput = edtText.getText().toString();
    }

    public void softSimLink(View view)
    {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
    }

    public  static String saveDate()
    {
        String myDate = "";

        Date date = new Date();

        SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy/M/d HH:mm:ss");

        myDate = simpleFormat.format(date);


        return myDate;
    }
    public void loadAirtime(View view)
    {
        if(edtText.getText().toString().equals("*134*9836*8#"))
        {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
            //Toast.makeText(TopUpActivity.this,"Top up was successful",Toast.LENGTH_SHORT).show();

            AlertDialog.Builder builder = new AlertDialog.Builder(TopUpActivity.this);

            builder.create();

            builder.setTitle("SoftSim new balance");
            builder.setMessage("Date: " + saveDate()+"\n-----------------------------------");
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });

            builder.show();

        }else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(TopUpActivity.this);

            builder.create();

            builder.setTitle("Unknown number");
            builder.setMessage("Please check the number and try again!");
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });

            builder.show();
        }

    }
}
