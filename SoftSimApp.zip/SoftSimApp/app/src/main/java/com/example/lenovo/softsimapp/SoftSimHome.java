package com.example.lenovo.softsimapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.w3c.dom.Element;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SoftSimHome extends AppCompatActivity {
    //private SearchContactsListAdapter searchAdapter;

    EditText edtCallOn,edtReceiveOn,phoneNumber;
    double valuD=0;
    double amt =0;
    String result = "";

    String numberTocall = "";
    String reciveOn = "";
   SharedPreferences pref;
    SharedPreferences.Editor mEditor;
    LocationManager locationManager;
    static ImageView updown;
    List<String> phoneList = new ArrayList<String>();

    String APIKEY = "b05a9b6599b7d323ae71";
    TextView textview2;

    String MolepoKey = "25c0f00d96451b2edf5e";

    static String cc = "";
    //static ImageView updown;

    IntentFilter filter = new IntentFilter();
    String[] list = new String[C.locales.length];
    public static HashMap<String, String> listH = new HashMap<String, String>();
    public static ArrayList<String> listA = new ArrayList<String>();

    Person person;
    String call_num = "";

    public static String mSearchTerm;
    private boolean mIsSearchResultView = false;
    public static MenuItem searchItem, regItem = null;

    // Defines a tag for identifying log entries
    private static final String tag = "ContactsListActivity";
    //private ContactDetailFragment mContactDetailFragment;
    // If true, this is a larger screen device which fits two panes
    private boolean isTwoPaneLayout;
    private boolean trZeroButton = false;
    // True if this activity instance is a search result view (used on pre-HC devices that load
    // search results in a separate instance of the activity rather than loading results in-line
    // as the query is typed.

    private boolean isSearchResultView = false;
    public static boolean isVerified = true;
    public static boolean AUTH = false;
    public static boolean phonebook = true, ccpopup = false;
    public static Uri curUser = null;
    LinearLayout oView;
    public static String callNow = null;
    public static String phoneGlobal = "";
    public static long resumeBlock = 0l;
    public static long syncBlock = 0l;
    String userDetails = "";
    //EditText phoneNumber;

    ImageView imageview;

    String clientPhonenumber="";
    Element element2;

    //EditText etData,edtnumberToCall;
    //Button btn;
    //String callURL;
    static Context context;
    //List<String> phoneList = new ArrayList<String>();
    static TableLayout dialpad;

    static LinearLayout call_cont, cont_number, del, cont;
    ArrayList<String> StoreContacts ;
    ArrayAdapter<String> arrayAdapter ;

    //
    // String myphonename, phonenumber ;
    public  static final int RequestPermissionCode  = 1;
    String databaseAPIKEY = ""; //"686e669fbef4f969515c"To be replaced with the key from database 686e669fbef4f969515c

    String date = "";
    private String LOG_TAG = "XML";
    private int UpdateFlag = 0;
    String Name="";
    String Range ="";
    ArrayList<String> urls=new ArrayList<String>();
    //String myXmlString = "<name>Bennette Lesetja Molepo</name>";
    ProgressDialog progressDialog;
    String myResponse = "";
    TextView txtString;
    ImageView imageView;

    String callingnumber = "";
    String name="";
    //String phoneNumber="";
    long id = 0;
    //String apikey = "";//"1ea9a91f6f53558d9203";//7dd8621c007eafa8e935//TO BE REPLACED BY THE ONE FROM CLIENT DATABASE 686e669fbef4f969515c
    ListView myListView;
    //Cursor cursor;
    String phones = "";
    private static final int REQUEST_READ_CONTACTS = 444;
    private ListView mListView;
    private ProgressDialog pDialog;
    private Handler updateBarHandler;
    ArrayList<String> contactList;
    Cursor cursor;
    ListView listView;


    int counter;
    String maruURL = "https://clientarea.maru.africa/cart.php?a=add&pid=24";
    // maruURL = "https://clientarea.maru.africa/cart.php?a=add&pid=24";
    // public String url = "https://greydotapi.me/?k=686e669fbef4f969515c&do=5";
    String newClientAPIKey = "";
    String clientMobile="";
    ClientDB clientDB;
    SimpleCursorAdapter simpleCursorAdapter;
    String fileAPI = "";
    String[] from;
    int[] to;

    String lastname="";String firstname="";String email="";String mobile="";String password="";String identity="";
    //String identity="";
    String apikey="";
    SearchView searchView;

    String intentKey = "";


    //"https://greydotapi.me/?k=686e669fbef4f969515c&do=5";
    public String url= "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soft_sim_home);
        clientDB = new ClientDB(this);

        person  = new Person();

        clientPhonenumber = person.getMobile();
        //cursor = clientDB.getData();

        /**if(cursor.moveToFirst()) {

            //int DBid = cursor.getInt(0);
            firstname = cursor.getString(1);
            lastname = cursor.getString(2);
            identity = cursor.getString(3);
            password = cursor.getString(4);
            email = cursor.getString(5);
            mobile = cursor.getString(6);
            //password = cursor.getString(5);
            //identity = cursor.getString(6);
            apikey = cursor.getString(7);


        }*/

       try {
            run();
        } catch (IOException e) {
            e.printStackTrace();
        }


        //searchView = (SearchView)findViewById(R.id.action_search);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.ic_launcher);

        //BIND VIEW ELEMENTS TO JAVA CLASS VARIABLES
        cont = (LinearLayout) findViewById(R.id.cont);
        cont_number = (LinearLayout) findViewById(R.id.cont_number);
        del = (LinearLayout) findViewById(R.id.del);
        phoneNumber = (EditText) findViewById(R.id.phoneNumber);
        clientMobile = phoneNumber.getText().toString();
        imageview = (ImageView) findViewById(R.id.imageView);


        //Button button = (Button)findViewById(R.id.btnCall) ;
       //button.setBackgroundColor(Color.GREEN);


        //Intent intent = getIntent();
        //apikey = (String)intent.getSerializableExtra("");
        //dialpad = (TableLayout)findViewById(R.id.dialpad);
        //call_cont = (LinearLayout)findViewById(R.id.call_cont);


        phoneNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeKeyboard();

            }
        });

        dialpad = (TableLayout) findViewById(R.id.dialpad);
        call_cont = (LinearLayout) findViewById(R.id.call_cont);
        //updown = (ImageView)findViewById(R.id.updown);

        //call(phoneNumber.getText().toString());

        //DIALPAD BUTTON ARRAY
        String[] dialpad_buttons = {"0","1","2","3","4","5","6","7","8","9","0","*","#"};
        int[] dialpad_buttons_ids = {R.id.button0,R.id.button1,R.id.button2,R.id.button3,R
                .id.button4,R.id.button5,R.id.button6,R.id.button7,R.id.button8,R.id.button9,R.id.button0,R.id.buttonstar,R.id.buttonpound};
        //SET CLICK LISTENERS FOR EACH DIALPAD BUTTON
        for(int c=0;c<dialpad_buttons_ids.length;c++){

            ImageButton t = (ImageButton) findViewById(dialpad_buttons_ids[c]);
            t.setTag(dialpad_buttons[c]);
            t.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p) {

                    phoneNumber.setVisibility(View.VISIBLE);
                    imageview.setVisibility(View.VISIBLE);

                    if(trZeroButton){ trZeroButton = false; return; }
                    int sel = phoneNumber.getSelectionStart();
                    //APPEND CHARACTE TO CREATE PHONE NUMBER
                    String s1 = phoneNumber.getText().toString().substring(0, sel);
                    String s2 = phoneNumber.getText().toString().substring(sel, phoneNumber.getText().length());
                    String temp = s1+p.getTag().toString()+s2;

                    //String temp = phoneNumber.getText().toString();
                    //temp+=p.getTag().toString();
                    dialpadPress(temp);
                    //MOVE CURSOR TO AN END
                    phoneNumber.setSelection(sel+1);
                    //phoneNumber.setSelection(phoneNumber.getText().length());
                }});
        }

        //SET LONG CLICK LISTENER FOR PLUS
        ImageButton button0 = (ImageButton) findViewById(R.id.button0);
        button0.setOnLongClickListener(new View.OnLongClickListener(){

            @Override
            public boolean onLongClick(View paramView) {

                int sel = phoneNumber.getSelectionStart();
                trZeroButton = true;
                //APPEND CHARACTE TO CREATE PHONE NUMBER
                String s1 = phoneNumber.getText().toString().substring(0, sel);
                String s2 = phoneNumber.getText().toString().substring(sel, phoneNumber.getText().length());
                String temp = s1+"+"+s2;

                //String temp = phoneNumber.getText().toString();
                //temp+="+";

                dialpadPress(temp);
                //MOVE CURSOR TO AN END OF EDIT TEXT
                //phoneNumber.setSelection(phoneNumber.getText().length());
                phoneNumber.setSelection(sel+1);
                return false;
            }});


        //LONG PRESS COMPLETELY REMOVE PHONE NUMBER FOMR EDIT TEXT
        del.setOnLongClickListener(new View.OnLongClickListener(){

            @Override
            public boolean onLongClick(View paramView) {

                //C.log("ggg", "LOJNG PRESSEDE");
                dialpadPress("");
                return true;
            }});


        //ANDROID BUG - DISABLE KEYBOARD POPUP WITH ANY METHOD..
        //phoneNumber.setInputType(0);
        phoneNumber.setLongClickable(false);
        disableSoftInputFromAppearing(phoneNumber);

        //phoneNumber.setKeyListener(null);
        // Check if two pane bool is set based on resource directories
        isTwoPaneLayout = getResources().getBoolean(R.bool.has_two_panes);


        cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

        listView = (ListView) findViewById(R.id.listView);

        cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

       String[] from = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone._ID};

        int[] to = {android.R.id.text1, android.R.id.text2};

        simpleCursorAdapter = new SimpleCursorAdapter(this, android.R.layout.simple_list_item_1, cursor, from, to);



        listView.setAdapter(simpleCursorAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                /**Cursor phones = getContentResolver().query(
                 ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,
                 ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = "+ id,
                 null, null);
                 phones.moveToFirst();
                 cNumber = phones.getString(phones.getColumnIndex("data1"));
                 System.out.println("number is:"+cNumber);
                 */

                //String phoneNumber = ContactsContract.CommonDataKinds.Phone.NUMBER;

                phoneNumber.setVisibility(View.VISIBLE);
                phones = cursor.getString((cursor.getColumnIndex("data1")));
                phoneNumber.setText(phones);


            }
        });


       // Toast.makeText(getApplicationContext(), "Welcome to Maru Africa SoftSIM App", Toast.LENGTH_LONG).show();

        }
    void run() throws IOException {

        //1ea9a91f6f53558d9203
        //url = "https://greydotapi.me/?k=1ea9a91f6f53558d9203"+"&do=5";
        cursor = clientDB.getData();

      /**  if(cursor.moveToFirst()) {

            //int DBid = cursor.getInt(0);
            firstname = cursor.getString(1);
            lastname = cursor.getString(2);
            identity = cursor.getString(3);
            password = cursor.getString(4);
            email = cursor.getString(5);
            mobile = cursor.getString(6);
            //password = cursor.getString(5);
            //identity = cursor.getString(6);
            apikey = cursor.getString(7);


        }*/
        Uri.Builder builder = new Uri.Builder();

        //"526c915430f835fa19c1")

        builder.scheme("https")
                .authority("greydotapi.me")
                .appendQueryParameter("k", cursor.getString(7))
                .appendQueryParameter("do", "5");
        url = builder.build().toString();
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();



        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                myResponse  = response.body().string();

                SoftSimHome.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        //txtString.setText(myResponse);


                    }
                });


            }
        });


    }

    public void closeKeyboard()
    {
        View v = this.getCurrentFocus();
        if(v != null)
        {
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(v.getWindowToken(),0);
        }
    }


//TO ENABLE OTHER USER ACCOUNT FEATURES ON MARUSIP APP
   // https://greydotapi.me/?k=1ea9a91f6f53558d9203&do=21&par1=on&par2=25911189630&par3=5178056662&par4=5-6-8-21



   /** public void ParseXML(String xmlString){

        try {

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader(xmlString));
            int eventType = parser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT){

                if(eventType== XmlPullParser.START_TAG){

                    String name = parser.getName();
                    if(name.equals("query_result")){

                        String ref = parser.getAttributeValue(null,"ref");
                        Log.d(LOG_TAG,"ref:" + ref);

                        if(parser.next() == XmlPullParser.TEXT) {
                            String UpdateFlag = parser.getText();
                            Log.d(LOG_TAG,"query_result:" + UpdateFlag);
                        }


                    }else if(name.equals("dots")) {

                        if(parser.next() == XmlPullParser.TEXT) {
                            Name = parser.getText();
                            Log.d(LOG_TAG,"dots: " + Name);

                            valuD= Double.valueOf(Name.toString());
                           amt = valuD/10;

                            result = String.format("%.2f", amt);

                        }
                    }else if(name.equals("status")) {

                        if(parser.next() == XmlPullParser.TEXT) {
                            Range = parser.getText();
                            Log.d(LOG_TAG,"status:" + Range);
                            if(Range.equals("Success"))
                            {
                                //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.marusip.com/?pan=login")));
                            }else
                            {
                                Toast.makeText(this,"Error loading up",Toast.LENGTH_SHORT).show();
                            }
                        }
                    }


                }else if(eventType== XmlPullParser.END_TAG){


                }
                eventType = parser.next();


            }



        }catch (Exception e){
            Log.d(LOG_TAG,"Error in ParseXML()",e);
        }

    }*/


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_menu,menu);


        return true;
    }

    //private static boolean trSearch = false;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //searchView = (SearchView)item.getActionView();
        //View itemAction = item.getActionView();
        //noinspection SimplifiableIfStatement

        if (id == R.id.action_addcontact) {

            Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            startActivity(intent);
            return true;
        }
        else  if (id == R.id.chechbalance) {
            //checkBalance();

            progressDialog  = new ProgressDialog(SoftSimHome.this);

            progressDialog.setTitle("Checking your balance");
            progressDialog.setMessage("Please wait...");
            progressDialog.show();

            // https://greydotapi.me/?k=8a7758a8ddb69b417375&do=5
            cursor = clientDB.getData();


           /** if(cursor.moveToFirst()) {

              // firstname = cursor.getString(1);
               // lastname = cursor.getString(2);
                //identity = cursor.getString(3);
                //password = cursor.getString(4);
              //  email = cursor.getString(5);
               // mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);
                apikey = cursor.getString(7);


            }*/
            //526c915430f835fa19c1   1ea9a91f6f53558d9203 //526c915430f835fa19c1
            String smsURL  = "https://greydotapi.me/?k="+cursor.getString(7)+"&do="+5;

            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(smsURL)
                    .build();


            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    call.cancel();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {

                    myResponse  = response.body().string();

                    SoftSimHome.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            //txtString.setText(myResponse);


                        }
                    });


                }
            });

            try {

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser parser = factory.newPullParser();
                parser.setInput(new StringReader(myResponse));
                int eventType = parser.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT){

                    if(eventType== XmlPullParser.START_TAG){

                        String name = parser.getName();
                        if(name.equals("query_result")){

                            String ref = parser.getAttributeValue(null,"ref");
                            Log.d(LOG_TAG,"ref:" + ref);

                            if(parser.next() == XmlPullParser.TEXT) {
                                String UpdateFlag = parser.getText();
                                Log.d(LOG_TAG,"query_result:" + UpdateFlag);
                            }


                        }else if(name.equals("dots")) {

                            if(parser.next() == XmlPullParser.TEXT) {
                                Name = parser.getText();
                                Log.d(LOG_TAG,"dots: " + Name);

                                valuD= Double.valueOf(Name.toString());
                                amt = valuD/10;

                                result = String.format("%.2f", amt);

                            }
                        }else if(name.equals("status")) {

                            if(parser.next() == XmlPullParser.TEXT) {
                                Range = parser.getText();
                                Log.d(LOG_TAG,"status:" + Range);
                                if(Range.equals("Success"))
                                {
                                    Toast.makeText(this,"You will get a balance now",Toast.LENGTH_SHORT).show();
                                }else
                                {
                                   Toast.makeText(this,"Error loading up",Toast.LENGTH_SHORT).show();
                                }
                            }
                        }


                    }else if(eventType== XmlPullParser.END_TAG){


                    }
                    eventType = parser.next();


                }



            }catch (Exception e){
                Log.d(LOG_TAG,"Error in ParseXML()",e);
            }

            AsyncHttpClient asycnHttpClient = new AsyncHttpClient(true, 60, 443);
            // AsyncHttpClient client = new AsyncHttpClient();
            asycnHttpClient.get(smsURL, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                    date = SaveDate();
                    progressDialog.dismiss();


                    AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimHome.this);

                    builder.create();
                    builder.setTitle("SoftSIM Balance");
                    builder.setMessage("Your balance is R "+result);
                    builder.setMessage("Date: " +date +"\n---------------------------------------------------"+"\nAirtime R"
                                    +result);
                    builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub


                        }
                    });

                    builder.setNegativeButton("SMS", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            Intent intent = new Intent(SoftSimHome.this,SendingSMS.class);
                            intent.putExtra("phone",phones);
                            startActivity(intent);

                        }
                    });

                    builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            Intent intent = new Intent(SoftSimHome.this,SoftSimHome.class);
                            startActivity(intent);

                        }
                });

                    builder.setNeutralButton("TOP UP", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub

                            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
                            Intent intent = new Intent(SoftSimHome.this,TopUp.class);
                            startActivity(intent);
                        }
                    });
                    AlertDialog alert = builder.create();

                    alert.show();

                }

                @Override
                public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                    progressDialog.dismiss();

                    AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimHome.this);

                    builder.create();
                    builder.setTitle("Failed to check your balance");
                    builder.setMessage("Please check your internet connection and try again");
                    builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub


                        }
                    });

                    AlertDialog alert = builder.create();

                    alert.show();
                }


            });



            return true;
        }else  if (id == R.id.topup) {

            Intent intent = new Intent(SoftSimHome.this,TopUp.class);
            startActivity(intent);

           // topup();

            return true;
        }else  if (id == R.id.history) {
            Intent intent = new Intent(SoftSimHome.this,CallHistory.class);
            startActivity(intent);
            return true;
        }else  if (id == R.id.ClientDetails) {

            cursor = clientDB.getData();


            if(cursor.moveToFirst())
            {

                //int DBid = cursor.getInt(0);
                firstname = cursor.getString(1);
                lastname = cursor.getString(2);
                identity = cursor.getString(3);
                password = cursor.getString(4);
                email = cursor.getString(5);
                mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);
                apikey = cursor.getString(7);


            }

            AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimHome.this);

            builder.create();
            builder.setTitle("My Profile");

          builder.setMessage("Fisrt name: "+firstname+"\nLast name: "+lastname+"\nEmail: "+email+"\nMobile: "
                    +mobile+"\nPassword: " +password+" "+"\nIdentity: " +identity+" "+"\nApi Key: " + apikey);

            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub


                }
            });

            AlertDialog alert = builder.create();

            alert.show();

            return true;
        }else  if (id == R.id.Aboutus) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.maru.africa")));
            Intent intent = new Intent(SoftSimHome.this,AboutUs.class);
           startActivity(intent);
            return true;
        }else  if (id == R.id.Help) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maru.bitrix24.com/online/clientchannel")));
            //https://maru.bitrix24.com/online/clientchannel

            Intent intent = new Intent(SoftSimHome.this,Help.class);
            startActivity(intent);

            return true;
        }/**else if(id == R.id.action_search)
        {


            listView.setAdapter(simpleCursorAdapter);

            phoneNumber.addTextChangedListener(new TextWatcher() {
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}

                @Override
                public void beforeTextChanged(CharSequence s, int start, int count,
                                              int after) {}

                @Override
                public void afterTextChanged(Editable s) {
                    searchContacts(phoneNumber.getText().toString());
                }
            });

        }*/



        return super.onOptionsItemSelected(item);
    }


    public static void disableSoftInputFromAppearing(EditText editText) {
        if (Build.VERSION.SDK_INT >= 11) {
            editText.setRawInputType(InputType.TYPE_CLASS_TEXT);
            editText.setTextIsSelectable(true);
        } else {
            editText.setRawInputType(InputType.TYPE_NULL);
            editText.setFocusable(true);
        }
    }
    //SLIDE UP DIALPAD - this method is invoked from contact_list_fragment.xml
    public void showDialpad(){

        dialpad = (TableLayout) findViewById(R.id.dialpad);
        //HIDE IF VISIBLE
        if(dialpad.getVisibility()==View.VISIBLE){

            dialpad.setVisibility(View.GONE);
            //updown.setImageDrawable(getResources().getDrawable(R.drawable.ic_up));

            //SHOW IF NOT VISIBLE
        }else{

            dialpad.setVisibility(View.VISIBLE);
            //updown.setImageDrawable(getResources().getDrawable(R.drawable.ic_down));
        }
    }

    //ONLY SLIDE UP DIALPAD - this method is invoked from contact_list_fragment.xml
    public void showDialpadUp(View v){


        dialpad = (TableLayout) findViewById(R.id.dialpad);
        //SHOW IF NOT VISIBLE
        if(dialpad.getVisibility()!=View.VISIBLE){

            dialpad.setVisibility(View.VISIBLE);
            //updown.setImageDrawable(getResources().getDrawable(R.drawable.ic_down));
        }
    }





    public static String SaveDate() {

        String Mydate = "";

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/M/d HH:mm:ss");
        Mydate = sdf.format(date);

        return  Mydate;
    }


    public void sendsms(View view)
    {
        Intent intent = new Intent(SoftSimHome.this,SendingSMS.class);
        intent.putExtra("phone",phones);
        startActivity(intent);
    }
   /** public void topup()
    {


        AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimHome.this);

        builder.create();
        builder.setTitle("Important notice");
        builder.setMessage("Please use your identity and password to login, you can find those within your sms");
        builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub


            }
        });

        AlertDialog alert = builder.create();

       // alert.show();
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
        //Intent intent = new Intent(SoftSimHome.this,TopUpActivity.class);
        //startActivity(intent);
    }
*/


    /**public void checkBalance()
    {
        int duration = Toast.LENGTH_SHORT;

        String date = SaveDate();

       // double db = (Double.parseDouble(Name.toString()));




       // String.format("%d %.2f", amt);
        ParseXML(myResponse);

        AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimHome.this);

        builder.create();
        builder.setTitle("SoftSIM Current balance");
        builder.setMessage("Date: " +date +"\n---------------------------------------------------"+"\nAirtime R"
                +result +"\nStatus: " + Range);
        builder.setNegativeButton("SMS", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(SoftSimHome.this,SendingSMS.class);
                intent.putExtra("phone",phones);
                startActivity(intent);

            }
        });

        builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                //Intent intent = new Intent(SoftSimHome.this,SoftSimHome.class);
                //startActivity(intent);

            }
        });

        builder.setNeutralButton("TOP UP", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub

                //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
               Intent intent = new Intent(SoftSimHome.this,TopUp.class);
               startActivity(intent);
            }
        });



        AlertDialog alert = builder.create();

        alert.show();

    }*/


    //START ASYNC TIMER IN LOOP TO CHECK EMAIL VERIFICATION ON SERVER - WORKS ONLY WHEN MAIN SCREEN OF zvonivru IS ACTIVE
    private boolean trVerBlock = false;
    final Handler h = new Handler();
    public static android.app.AlertDialog dialog;

    public void dialpadPress(String c){
        //TODO
        phoneNumber.setText(c);

    }    //ONLY SLIDE UP DIALPAD - this method is invoked from contact_list_fragment.xml


    //DEL CHARACTER
    public void delChar(View v){

        String temp = phoneNumber.getText().toString();
        if(temp.length()>0){

            int sel = phoneNumber.getSelectionStart();
            //APPEND CHARACTE TO CREATE PHONE NUMBER
            if(sel>0){
                String s1 = phoneNumber.getText().toString().substring(0, sel-1);
                String s2 = phoneNumber.getText().toString().substring(sel, phoneNumber.getText().length());
                String temp2 = s1+s2;

                //String temp = phoneNumber.getText().toString();
                //temp+=p.getTag().toString();
                dialpadPress(temp2);
                //MOVE CURSOR TO AN END
                phoneNumber.setSelection(sel-1);

                //phoneNumber.setText(temp2.substring(0, temp2.length()-1));
                //MOVE CURSOR TO AN END OF EDIT TEXT
                //phoneNumber.setSelection(phoneNumber.getText().length());
            }
        }
    }


    //LISTENER FOR CALL NOW BUTTON
   /** public void callNow(View v){

        if(phoneNumber.getText().toString().length()==0){

            Toast.makeText(context,"Please provide valid number", Toast.LENGTH_SHORT).show();
        }else{
            phonebook = false;
            callNowL();


        }



    }*/

    //CALL NOW LOCAL METHOD
   /** public void callNowL(){

        //if(!isVerified){notVerified();}else{call(phoneNumber.getText().toString());}
        call(phoneNumber.getText().toString());
    }
*/
    //CALL METHOD
   /** public void call(String phone){

        callNow = null;
        String phoneOr = phone;
        //если начинается на 8 заменяешь на 8 на +7
        if(phone.startsWith("8") && phone.length()>10) phone = "+7" + phone.substring(1, phone.length());

        //CHECK IF VALID OR NOT
        if(phone.length()>0){

            //PERFORM CALL

            //Toast.makeText(getApplicationContext(), phone, Toast.LENGTH_LONG).show();
            //INSERT CALL RECORD
            String description = "call";
            String from = "Я";
            String to = phoneOr;
            String duration = "0.00";
            String deb = "0.00";
            String cre = "0.00";
            String country = "US";
            Integer type = 4;

            DataBaseAdapter db = new DataBaseAdapter(context);
            db.open();
            db.insertReport(System.currentTimeMillis(), description, from, to, duration, 0f, country, Integer.valueOf(type));
            db.close();
            //PREPARE CALL INTENT
            // Intent callIntent = new Intent(Intent.ACTION_CALL);
            //C.log("Call Parser", Uri.parse("tel:"+(pref.getString("IVR_"+cc.toUpperCase(), "+37125415609")+"*")+phone).toString());
            //callIntent.setData(Uri.parse("tel:"+phone));


            //startActivity(callIntent);
            callURL = "https://greydotapi.me/?par1=0782098815&par2="+phoneNumber.getText().toString()+"&k="+databaseAPIKEY+"&do="+8;

            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(callURL)));

        }else{

            //badPhonePopup(this, phoneOr, R.string.number2);
        }
    }*/
   //String phoneOr = phoneNumber.getText().toString();
   public void makecall(View view)
   {

       progressDialog  = new ProgressDialog(SoftSimHome.this);

       /** if(amt<= 0)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimHome.this);

            builder.create();
            builder.setTitle("Call not forwarded");
            builder.setMessage("You have no credit to make a call,please load up your account first");
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub


                }
            });

            AlertDialog alert = builder.create();

            alert.show();

        }else if(amt>0)
        {



            }*/

       progressDialog.setTitle("Calling");
       progressDialog.setMessage("Please wait while we start your call");


       cursor = clientDB.getData();


       if(cursor.moveToFirst()) {

          // firstname = cursor.getString(1);
          // lastname = cursor.getString(2);
          // identity = cursor.getString(3);
           //password = cursor.getString(4);
           //email = cursor.getString(5);
           mobile = cursor.getString(6);
           //password = cursor.getString(5);
           //identity = cursor.getString(6);
           apikey = cursor.getString(7);

           cursor.moveToNext();


            if(phoneNumber.getText().toString().length()==0 ||phoneNumber.getText().toString().length()<10)
            {
                Intent intent = new Intent(SoftSimHome.this,SoftSimHome.class);
                Toast.makeText(this,"Please enter mobile number",Toast.LENGTH_LONG).show();
                startActivity(intent);
            }else
            {
                progressDialog.show();


                //apikey >>>>>>>must use this key 526c915430f835fa19c1
                String callURL = "https://greydotapi.me/?par1="+phoneNumber.getText().toString()+"&par2="+mobile+"&k="+apikey+"&do="+1;


                AsyncHttpClient asycnHttpClient = new AsyncHttpClient(true, 80, 443);
                // AsyncHttpClient client = new AsyncHttpClient();
                asycnHttpClient.get(callURL, new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                        progressDialog.dismiss();

                        AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimHome.this);

                        builder.create();
                        builder.setTitle("Calling");
                        builder.setMessage(mobile+" :  Answer incoming call to initiate softSIM call To: " + phoneNumber.getText().toString());
                        builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub


                            }
                        });

                        AlertDialog alert = builder.create();

                        alert.show();
                    }

                    @Override
                    public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                        progressDialog.dismiss();

                        AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimHome.this);

                        builder.create();
                        builder.setTitle("Connection Failed");
                        builder.setMessage("Please check your internet connection and Try Again");
                        builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // TODO Auto-generated method stub


                            }
                        });

                        AlertDialog alert = builder.create();

                        alert.show();
                    }


                });
                //INSERT CALL RECORD
                String description = "Call";
                String from = mobile;
                String to = phoneNumber.getText().toString();
                String duration = "0.00";
                String deb = "0.00";
                String cre = "0.00";
                String callDate =  SaveDate();

                Integer type = 4;

                //String time, String description, String from, String to,int type)
                //clientDB.insertReport(callDate, description,from,to,type);

                clientDB.insertReport(callDate,description,from,to,type);

                // clientDB.insertReport(System.currentTimeMillis(), description, phoneNumber.getText().toString(),mobile, duration,callDate, Integer.valueOf(type));
                // (Long time, String description, String from, String to, String duration, Float amount, String cc, int type)



                /** AsyncHttpClient client = new AsyncHttpClient();
                 client.get(callURL,  new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(callURL)));

                android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(SoftSimHome.this);

                builder.create();
                builder.setTitle("Connecting");
                builder.setMessage(mobile+" : Please answer in coming call to initiate softSIM call To: " + phoneNumber.getText().toString());
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub


                }
                });

                android.support.v7.app.AlertDialog alert = builder.create();

                alert.show();
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {



                android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(SoftSimHome.this);

                builder.create();
                builder.setTitle("Connection Failed");
                builder.setMessage("Please check your balance and Try Again");
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub


                }
                });

                android.support.v7.app.AlertDialog alert = builder.create();

                alert.show();
                }
                });
                 */

            }

        }





   }

   public void makesCallings(View view)
   {
       //Intent intent = new Intent(SoftSimHome.this,SoftSimHome.class);
       //startActivity(intent);
   }
    public void conectionss(View view)
    {
        Intent intent = new Intent(SoftSimHome.this,ConnectFriends.class);
        startActivity(intent);
    }

    //METHOD TO EXIT TH APP
    boolean twice;

    @Override
    public void onBackPressed() {
        // super.onBackPressed();

        if(twice ==true)
        {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
            System.exit(0);
        }
        Toast.makeText(SoftSimHome.this,"Please press back again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                twice = false;

            }
        },300);

        twice = true;
    }

}
