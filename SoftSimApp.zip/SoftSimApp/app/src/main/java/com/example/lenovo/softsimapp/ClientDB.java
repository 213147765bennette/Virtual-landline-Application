 package com.example.lenovo.softsimapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Lenovo on 2018-03-06.
 */

public class ClientDB extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "softSIMDBben.db";
    public static final String CLIENT_TABLE_NAME = "clients";

    public static final String CLIENT_COLUMN_ID = "_id";
    public static final String CLIENT_COLUMN_NAME = "name";
    public static final String CLIENT_COLUMN_SURNAME = "surname";
    public static final String CLIENT_COLUMN_USERNAME = "username";
    public static final String CLIENT_COLUMN_PASSWORD= "password";
    public static final String CLIENT_COLUMN_EMAIL = "email";
    public static final String CLIENT_COLUMN_PHONE = "phone";
    //public static final String CLIENT_COLUMN_CLIENT = "client";
    public static final String CLIENT_COLUMN_APPKEY = "key";



    public ClientDB(Context context) {
        super(context, DATABASE_NAME , null, 1);
    }

    //INSERT INTO clients(clientKey,phone,email,surname,name,password,username)


    //REPORT TABLE
    /**private static final String Table3 =
            "create table if not exists report("
                    + "time integer null," //time
                    + "description String null," //call from
                    + "_from String null," //call from
                    + "_to String null," //call to
                    + "duration String null," //duration
                    + "amount Float null," //duration
                    + "cc String null," // date
                    + "type integer null" // operation type | 0 - неизвестно что 1 - пополнение баланса 2 - списание (не звонок) 3 - входящий звонок 4 - исходящий звонок 5 - отзвон 6 - неотвеченый вызов
                    +");";*/

    private static final String Table4 =
            "create table if not exists logs("
                    + "time String null," //time taken
                    + "description String null," //description
                    + "_from String null," //call from
                    + "_to String null," //call to
                    + "type integer null"
                    +");";

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
       /**db.execSQL(

                "create table clients " +
                "(id integer primary key autoincrement, name text,surname text,username text,password text,email text, phone text,clientKey text)"


        );*/



        db.execSQL(

                "create table clients " +
                        "(_id integer primary key, name text,surname text,username text,password text,email text, phone text,key text)"

        );

        db.execSQL(Table4);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS clients");
        db.execSQL("DROP TABLE IF EXISTS logs");
        onCreate(db);
    }

    //id integer primary key autoincrement, name text,surname text,username text,password text,email text, phone text,client text
    public boolean insertClient (String name,String surname,String username,String password,String email,String phone ,String clientApi) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", name);
        contentValues.put("surname", surname);
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("email", email);
        contentValues.put("phone", phone);
        contentValues.put("key", clientApi);
        db.insert(CLIENT_TABLE_NAME, null, contentValues);
        return true;
    }

    String cc = SoftSimHome.SaveDate();

    public void insertReport(String time, String description, String from, String to,int type){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues initialValues = new ContentValues();

        //initialValues.put("time", type);
        initialValues.put("time", time);
        if(description!=null && description.length()>0)
            initialValues.put("description", description);
        if(from!=null && from.length()>0)
            initialValues.put("_from", from);
        if(to!=null && to.length()>0)
            initialValues.put("_to", to);

        initialValues.put("type", type);

        //if(duration!=null && duration.length()>0)
           // initialValues.put("duration", duration);
        //if(amount!=null && amount.length()>0)
        //initialValues.put("amount", amount);
       //if(cc!=null)
           // initialValues.put("cc", cc);

        //Log.e("TYPe:", "kk"+type);
        db.insert("logs", null, initialValues);
    }

    //REPORT - INSERT RECORD
   /** public void insertReport(Long time, String description, String from, String to, String duration,String cc, int type){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues initialValues = new ContentValues();
        initialValues.put("time", time);
        if(description!=null && description.length()>0)
            initialValues.put("description", description);
        if(from!=null && from.length()>0)
            initialValues.put("_from", from);
        if(to!=null && to.length()>0)
            initialValues.put("_to", to);
        if(duration!=null && duration.length()>0)
            initialValues.put("duration", duration);
        //if(amount!=null && amount.length()>0)
        //initialValues.put("amount", amount);
       if(cc!=null)
            initialValues.put("cc", cc);
        initialValues.put("type", type);
        //Log.e("TYPe:", "kk"+type);
        db.insert("report", null, initialValues);
    }*/


   /** public boolean insertClient (String name,String surname,String email,String phone ,String clientApi) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        //contentValues.put("id", id);
        contentValues.put("name", name);
        contentValues.put("surname", surname);
        contentValues.put("email", email);
        contentValues.put("phone", phone);
        contentValues.put("key", clientApi);

        db.insert(CLIENT_TABLE_NAME, null, contentValues);

        //db.close();
        return true;
    }*/
    /**public void addProduct(Person person) {

     ContentValues values = new ContentValues();
     values.put(COLUMN_PRODUCTNAME, product.getProductName());
     values.put(COLUMN_QUANTITY, product.getQuantity());

     SQLiteDatabase db = this.getWritableDatabase();

     db.insert(TABLE_PRODUCTS, null, values);
     db.close();
     }*/

   /** public void addUser (Person person) {

        ContentValues contentValues = new ContentValues();
        //cv.put(COLUMN_TEAM_NAME, t.getTeamName());
        SQLiteDatabase db = this.getWritableDatabase();

        contentValues.put(CLIENT_COLUMN_NAME, person.getName());
        contentValues.put(CLIENT_COLUMN_SURNAME, person.getSurname());
        contentValues.put(CLIENT_COLUMN_USERNAME, person.getUsername());
        contentValues.put(CLIENT_COLUMN_PASSWORD, person.getPassword());
        contentValues.put(CLIENT_COLUMN_EMAIL, person.getEmail());
        contentValues.put(CLIENT_COLUMN_PHONE, person.getMobile());
        contentValues.put(CLIENT_COLUMN_APPKEY, person.getApikey());
        db.insert(CLIENT_TABLE_NAME, null, contentValues);
        db.close();
        //return true;
    }*/


   /** public void addApiKey(String myKey)
    {
        ContentValues contentValues = new ContentValues();
        SQLiteDatabase db = this.getWritableDatabase();

        contentValues.put("client", myKey);
        db.insert("clients", null, contentValues);

        //return true;

    }*/
    public Cursor getData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from clients ", null );
        return res;
    }

    /**public static String DatabaseDate() {

        String Mydate = "";

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/M/d HH:mm:ss");
        Mydate = sdf.format(date);

        return  Mydate;
    }*/


    //RATES - GET ONLY CALL RECORDS
    public Cursor getCalls(){
        SQLiteDatabase db = this.getReadableDatabase();
        String q = "SELECT * FROM logs where type > '2' AND type < '7' order by time DESC limit 100" ;
        return db.rawQuery(q, null);
    }


   /** public int numberOfRows(){
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, CLIENT_TABLE_NAME);
        return numRows;
    }*/


   /**** public String getuserAPIKey(String mobile)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        //Cursor res =  db.rawQuery( "select key from "+CLIENT_TABLE_NAME + " where " + CLIENT_COLUMN_PHONE + " = "+mobile, null );
       // String select = "Select * from " + TABLE_TEAM + " where " + COLUMN_ID + " = " + teamID;
        //Cursor c = db.rawQuery(select, null);

        String args[] = {mobile};
        String select = "SELECT client FROM clients WHERE mobile=?"+mobile;
        Cursor cursor = db.rawQuery(select, args);
                //"SELECT client FROM "+CLIENT_TABLE_NAME + " WHERE " + CLIENT_COLUMN_PHONE + " = "+mobile;
        //Cursor c = db.rawQuery(select, null);

        return select;
    }
   /* public String getclientUsername(String mobile)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        //Cursor res =  db.rawQuery( "select key from "+CLIENT_TABLE_NAME + " where " + CLIENT_COLUMN_PHONE + " = "+mobile, null );
        // String select = "Select * from " + TABLE_TEAM + " where " + COLUMN_ID + " = " + teamID;
        //Cursor c = db.rawQuery(select, null);

        String select = "Select username from "+CLIENT_TABLE_NAME + " where " + CLIENT_COLUMN_PHONE + " = "+mobile;
        Cursor c = db.rawQuery(select, null);

        return select;
    }
    public String getclientPassword(String mobile)
    {
        SQLiteDatabase db = this.getReadableDatabase();

        String select = "Select password from "+CLIENT_TABLE_NAME + " where " + CLIENT_COLUMN_PHONE + " = "+mobile;
        Cursor c = db.rawQuery(select, null);

        return select;
    }




    public Product findProduct(String productname) {
	String query = "Select * FROM " + TABLE_PRODUCTS + " WHERE " + COLUMN_PRODUCTNAME + " =  \"" + productname + "\"";

	SQLiteDatabase db = this.getWritableDatabase();

	Cursor cursor = db.rawQuery(query, null);

	Product product = new Product();

	if (cursor.moveToFirst()) {
		cursor.moveToFirst();
		product.setID(Integer.parseInt(cursor.getString(0)));
		product.setProductName(cursor.getString(1));
		product.setQuantity(Integer.parseInt(cursor.getString(2)));
		cursor.close();
	} else {
		product = null;
	}
	db.close();
	return product;
}



*/


    /*public Person getPerson(String phone)
    {
        //Person person = null;

        //SQLiteDatabase db = this.getReadableDatabase(); //you can be able to read from the database

        SQLiteDatabase db = this.getReadableDatabase();

        Person person = new Person();

       // String query = "Select * FROM " + CLIENT_TABLE_NAME + " WHERE " + CLIENT_COLUMN_PHONE + " = " +phone;
        String query = "Select * FROM  clients  WHERE mobile  "+" = " +phone;
       // Person person = null;

        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst())
        {
                person.setId(Integer.parseInt(cursor.getString(0)));
                person.setName(cursor.getString(1));
                person.setSurname(cursor.getString(2));
                person.setMobile(cursor.getString(3));
                person.setEmail(cursor.getString(4));
                person.setUsername(cursor.getString(5));
                person.setPassword(cursor.getString(6));
                person.setApikey(cursor.getString(7));

                cursor.close();

            }else
                {
                    person = null;
                }

                db.close();

        return person;
    }*/


    /*public boolean updateContact (Integer id, String name,String surname,String username,String password,String phone, String email,String client) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put("name", name);
        contentValues.put("surname", surname);
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("email", email);
        contentValues.put("phone", phone);
        contentValues.put("client", client);
        db.update("clients", contentValues, "id = ? ", new String[] { Integer.toString(id) } );
        return true;
    }*/

    /**public Integer deleteContact (Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("clients",
                "id = ? ",
                new String[] { Integer.toString(id) });
    }

    public ArrayList<String> getAllCotacts() {
        ArrayList<String> array_list = new ArrayList<String>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from clients", null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
            array_list.add(res.getString(res.getColumnIndex(CLIENT_COLUMN_NAME)));
            res.moveToNext();
        }
        return array_list;
    }*/
}
