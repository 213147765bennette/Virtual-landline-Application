package com.example.lenovo.softsimapp;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.SparseIntArray;


/**
 * Created by Lenovo on 2018-03-19.
 */

public abstract class PermissionClass extends Activity{

private SparseIntArray myErrorString;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         myErrorString = new SparseIntArray();
    }

    public  abstract  void onPermissionGranted(int requestCode);

    public  void requestAppPermission(final String[] requestedPermission,final int stringId,final int requestCode)
    {
        myErrorString.put(requestCode,stringId);

        int permissionCheck = PackageManager.PERMISSION_GRANTED;
        boolean showRequestPermissions = false;

        for(String permission: requestedPermission)
        {
            permissionCheck = permissionCheck + ContextCompat.checkSelfPermission(this,permission);
            showRequestPermissions = showRequestPermissions || ActivityCompat.shouldShowRequestPermissionRationale(this,permission);

        }

        if(permissionCheck!=PackageManager.PERMISSION_GRANTED)
        {
            if(showRequestPermissions)
            {

            }
        }
    }
}
