package com.example.lenovo.softsimapp;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class SendingSMS extends AppCompatActivity {
    private static final int RESULT_PICK_CONTACT = 855 ;
    String APIKEY = "b05a9b6599b7d323ae71"; //TO BE CHANGED BY THE ONE FROM DATABASE

    String lastname="";String firstname="";String email="";String mobile="";String password="";String identity="";
    //String identity="";
    //String apikey="";
    double valuD=0;
    double amt =0;
    String result = "";
     ProgressDialog progressDialog;
    String phones = "";
    private String LOG_TAG = "XML";
    private int UpdateFlag = 0;
    String Name="";
    String Range ="";
    public String url= "";

    Button buttonSend;
    EditText etMessage;
    String messageToSend = "";
    EditText textPhoneNo;
    EditText textSMS;
    String phoneNum = "";
    String phoneNo = "";
    String sms = "";
    String myResponse = "";
    //String smsURL = "";
    String apikey="25c0f00d96451b2edf5e";
    ClientDB clientDB;
    String TAG = "";

    Cursor cursor;
   // private static final String BASE_URL = "https://api.twitter.com/1/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sending_sms);
        buttonSend = (Button) findViewById(R.id.buttonSend);
        textPhoneNo = (EditText) findViewById(R.id.editTextPhoneNo);
        textSMS = (EditText) findViewById(R.id.editTextSMS);
        phoneNum = textPhoneNo.getText().toString();

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.ic_launcher);

        Intent intent = getIntent();
        String phone = (String)intent.getSerializableExtra("phone");
        etMessage = (EditText) findViewById(R.id.editTextSMS);

        if(phone.contains(" "))
        {
            phone.replace(" ","");
        }
        textPhoneNo.setText(phoneNum);
        messageToSend  = etMessage.getText().toString();

        clientDB = new ClientDB(this);


    }

    //TO PICK PHONE NUMBER FROM MY DEVICE

        protected void onActivityResult(int requestCode,int resultcode,Intent data)
        {
            if(resultcode==RESULT_OK)
            {
                switch(requestCode)
                {
                    case RESULT_PICK_CONTACT:ContactPicked(data);
                        break;
                }

            }else
            {
                Toast.makeText(this,"Failed to select mobile number",Toast.LENGTH_LONG).show();
            }
        }

    private void ContactPicked(Intent data)
    {
        Cursor cursor = null;
        try{

            String phoneNo = null;
            Uri uri = data.getData();

            cursor = getContentResolver().query(uri,null,null,null,null);
            cursor.moveToFirst();

            int phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

            phoneNo = cursor.getString(phoneIndex);
            textPhoneNo.setText(phoneNo);

        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void add_contact(View view)
    {
        Intent ContactPicIntent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
        startActivityForResult(ContactPicIntent,RESULT_PICK_CONTACT);

    }

    public void smsSend(View view)
    {

        progressDialog  = new ProgressDialog(SendingSMS.this);

        progressDialog.setTitle("Sending sms");
        progressDialog.setMessage("Please wait while the sms is been sent");
        progressDialog.show();

        //apikey >>>>>>>must use this key
        cursor = clientDB.getData();


        /**if(cursor.moveToFirst()) {

            //firstname = cursor.getString(1);
            //lastname = cursor.getString(2);
            //identity = cursor.getString(3);
            //password = cursor.getString(4);
            //email = cursor.getString(5);
            mobile = cursor.getString(6);
            //password = cursor.getString(5);
            //identity = cursor.getString(6);
            apikey = cursor.getString(7);


        }*/
        //526c915430f835fa19c1   1ea9a91f6f53558d9203 //526c915430f835fa19c1
        String smsURL  = "https://greydotapi.me/?par1="+textPhoneNo.getText().toString()+"&par2="+etMessage.getText().toString()+"\nFrom: "+cursor.getString(6)+"&k="+cursor.getString(7)+"&do="+11;



        //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(smsURL)));


        AsyncHttpClient asycnHttpClient = new AsyncHttpClient(true, 80, 443);
       // AsyncHttpClient client = new AsyncHttpClient();
        asycnHttpClient.get(smsURL, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                progressDialog.dismiss();

                AlertDialog.Builder builder = new AlertDialog.Builder(SendingSMS.this);

                builder.create();
                builder.setTitle("Sending sms...");
                builder.setMessage("Your SMS has been sent to: "+textPhoneNo.getText().toString());
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub


                    }
                });

                AlertDialog alert = builder.create();

                alert.show();

            }

            @Override
            public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                progressDialog.dismiss();

                AlertDialog.Builder builder = new AlertDialog.Builder(SendingSMS.this);

                builder.create();
                builder.setTitle("Failed to send sms");
                builder.setMessage("Please check your internet connection and try again");
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub


                    }
                });

                AlertDialog alert = builder.create();

                alert.show();
            }


        });



        }

    android.support.v7.widget.SearchView searchViewAction = null;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_menu,menu);

        return true;
    }

    //private static boolean trSearch = false;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //searchView = (SearchView)item.getActionView();
        //View itemAction = item.getActionView();
        //noinspection SimplifiableIfStatement

        if (id == R.id.action_addcontact) {

            Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            startActivity(intent);
            return true;
        }
        else  if (id == R.id.chechbalance) {

            progressDialog  = new ProgressDialog(SendingSMS.this);

            progressDialog.setTitle("Checking your balance");
            progressDialog.setMessage("Please wait...");
            progressDialog.show();

            // https://greydotapi.me/?k=8a7758a8ddb69b417375&do=5
            cursor = clientDB.getData();


           /** if(cursor.moveToFirst()) {

                firstname = cursor.getString(1);
                lastname = cursor.getString(2);
                identity = cursor.getString(3);
                password = cursor.getString(4);
                email = cursor.getString(5);
                mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);
                apikey = cursor.getString(7);


            }*/
            //526c915430f835fa19c1   1ea9a91f6f53558d9203 //526c915430f835fa19c1
            String smsURL  = "https://greydotapi.me/?k="+cursor.getString(7)+"&do="+5;

            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(smsURL)
                    .build();


            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    call.cancel();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {

                    myResponse  = response.body().string();

                    SendingSMS.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            //txtString.setText(myResponse);


                        }
                    });


                }
            });

            try {

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser parser = factory.newPullParser();
                parser.setInput(new StringReader(myResponse));
                int eventType = parser.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT){

                    if(eventType== XmlPullParser.START_TAG){

                        String name = parser.getName();
                        if(name.equals("query_result")){

                            String ref = parser.getAttributeValue(null,"ref");
                            Log.d(LOG_TAG,"ref:" + ref);

                            if(parser.next() == XmlPullParser.TEXT) {
                                String UpdateFlag = parser.getText();
                                Log.d(LOG_TAG,"query_result:" + UpdateFlag);
                            }


                        }else if(name.equals("dots")) {

                            if(parser.next() == XmlPullParser.TEXT) {
                                Name = parser.getText();
                                Log.d(LOG_TAG,"dots: " + Name);

                                valuD= Double.valueOf(Name.toString());
                                amt = valuD/10;

                                result = String.format("%.2f", amt);

                            }
                        }else if(name.equals("status")) {

                            if(parser.next() == XmlPullParser.TEXT) {
                                Range = parser.getText();
                                Log.d(LOG_TAG,"status:" + Range);
                                if(Range.equals("Success"))
                                {

                                }else
                                {
                                    //Toast.makeText(this,"Error loading up",Toast.LENGTH_SHORT).show();
                                }
                            }
                        }


                    }else if(eventType== XmlPullParser.END_TAG){


                    }
                    eventType = parser.next();


                }



            }catch (Exception e){
                Log.d(LOG_TAG,"Error in ParseXML()",e);
            }

            AsyncHttpClient asycnHttpClient = new AsyncHttpClient(true,50, 443);
            // AsyncHttpClient client = new AsyncHttpClient();
            asycnHttpClient.get(smsURL, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                    SoftSimHome softSimHome = new SoftSimHome();

                    String date = SoftSimHome.SaveDate();
                    progressDialog.dismiss();


                    AlertDialog.Builder builder = new AlertDialog.Builder(SendingSMS.this);

                    builder.create();
                    builder.setTitle("SoftSIM Balance");
                    builder.setMessage("Your balance is R "+result);
                    builder.setMessage("Date: " +date +"\n---------------------------------------------------"+"\nAirtime R"
                            +result);

                    builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub


                        }
                    });

                    builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            Intent intent = new Intent(SendingSMS.this,SoftSimHome.class);
                            startActivity(intent);

                        }
                    });

                    


                    builder.setNegativeButton("SMS", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            Intent intent = new Intent(SendingSMS.this,SendingSMS.class);
                            intent.putExtra("phone",phones);
                            startActivity(intent);

                        }
                    });


                    builder.setNeutralButton("TOP UP", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub

                            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
                            Intent intent = new Intent(SendingSMS.this,TopUp.class);
                            startActivity(intent);
                        }
                    });
                    AlertDialog alert = builder.create();

                    alert.show();

                }

                @Override
                public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                    progressDialog.dismiss();

                    AlertDialog.Builder builder = new AlertDialog.Builder(SendingSMS.this);

                    builder.create();
                    builder.setTitle("Failed to check your balance");
                    builder.setMessage("Please check your internet connection and try again");
                    builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub


                        }
                    });

                    AlertDialog alert = builder.create();

                    alert.show();
                }


            });



            return true;

           // checkBalance();
            //return true;
        }else  if (id == R.id.topup) {

            Intent intent = new Intent(SendingSMS.this,TopUp.class);
            startActivity(intent);

            // topup();

            return true;
        }else  if (id == R.id.history) {
            Intent intent = new Intent(SendingSMS.this,CallHistory.class);
            startActivity(intent);
            return true;
        }else  if (id == R.id.ClientDetails) {

            cursor = clientDB.getData();


            if(cursor.moveToFirst())
            {

                //int DBid = cursor.getInt(0);
                firstname = cursor.getString(1);
                lastname = cursor.getString(2);
                identity = cursor.getString(3);
                password = cursor.getString(4);
                email = cursor.getString(5);
                mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);
                apikey = cursor.getString(7);

            }
            AlertDialog.Builder builder = new AlertDialog.Builder(SendingSMS.this);

            builder.create();
            builder.setTitle("Client details");
            builder.setMessage("Fisrt name: "+firstname+"\nLast name: "+lastname+"\nEmail: "+email+"\nMobile: "
                    +mobile+"\nPassword: " +password+" "+"\nIdentity: " +identity+" "+"\nApi Key: " + apikey);
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub


                }
            });

            AlertDialog alert = builder.create();

            alert.show();

            return true;
        }else  if (id == R.id.Aboutus) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.maru.africa")));
            Intent intent = new Intent(SendingSMS.this,AboutUs.class);
            startActivity(intent);
            return true;
        }else  if (id == R.id.Help) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maru.bitrix24.com/online/clientchannel")));
            //https://maru.bitrix24.com/online/clientchannel

            Intent intent = new Intent(SendingSMS.this,Help.class);
            startActivity(intent);

            return true;
        }


        return super.onOptionsItemSelected(item);
    }

    /**void run() throws IOException {




        String mykey = apikey;

        //1ea9a91f6f53558d9203
        //url = "https://greydotapi.me/?k=1ea9a91f6f53558d9203"+"&do=5";
        Uri.Builder builder = new Uri.Builder();
        builder.scheme("https")
                .authority("greydotapi.me")
                .appendQueryParameter("k", "526c915430f835fa19c1")
                .appendQueryParameter("do", "5");
        url = builder.build().toString();


        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                myResponse  = response.body().string();

                SendingSMS.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        //txtString.setText(myResponse);


                    }
                });


            }
        });


    }*/

   /** public void ParseXML(String xmlString){

        try {

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader(xmlString));
            int eventType = parser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT){

                if(eventType== XmlPullParser.START_TAG){

                    String name = parser.getName();
                    if(name.equals("query_result")){

                        String ref = parser.getAttributeValue(null,"ref");
                        Log.d(LOG_TAG,"ref:" + ref);

                        if(parser.next() == XmlPullParser.TEXT) {
                            String UpdateFlag = parser.getText();
                            Log.d(LOG_TAG,"query_result:" + UpdateFlag);
                        }


                    }else if(name.equals("dots")) {

                        if(parser.next() == XmlPullParser.TEXT) {
                            Name = parser.getText();
                            Log.d(LOG_TAG,"dots: " + Name);

                            valuD= Double.valueOf(Name.toString());
                            amt = valuD/10;

                            result = String.format("%.2f", amt);

                        }
                    }else if(name.equals("status")) {

                        if(parser.next() == XmlPullParser.TEXT) {
                            Range = parser.getText();
                            Log.d(LOG_TAG,"status:" + Range);
                            if(Range.equals("Success"))
                            {
                                //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.marusip.com/?pan=login")));
                            }else
                            {
                                Toast.makeText(this,"Error loading up",Toast.LENGTH_SHORT).show();
                            }
                        }
                    }


                }else if(eventType== XmlPullParser.END_TAG){


                }
                eventType = parser.next();


            }



        }catch (Exception e){
            Log.d(LOG_TAG,"Error in ParseXML()",e);
        }

    }*/


    /*public static String SaveDate() {

        String Mydate = "";

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/M/d HH:mm:ss");
        Mydate = sdf.format(date);

        return  Mydate;
    }*/

   /* public void checkBalance()
    {
        int duration = Toast.LENGTH_SHORT;

        String date = SaveDate();

        // double db = (Double.parseDouble(Name.toString()));

        // String.format("%d %.2f", amt);
        ParseXML(myResponse);

        AlertDialog.Builder builder = new AlertDialog.Builder(SendingSMS.this);

        builder.create();
        builder.setTitle("SoftSIM Balance");
        builder.setMessage("Your balance is R "+result);
        builder.setMessage("Date: " +date +"\n---------------------------------------------------"+"\nAirtime R"
                +result);
        builder.setNegativeButton("SMS", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(SendingSMS.this,SendingSMS.class);
                intent.putExtra("phone",phones);
                startActivity(intent);

            }
        });

        builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(SendingSMS.this,SoftSimHome.class);
                startActivity(intent);

            }
        });

        builder.setNeutralButton("TOP UP", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub

                //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
                Intent intent = new Intent(SendingSMS.this,TopUp.class);
                startActivity(intent);
            }
        });



        AlertDialog alert = builder.create();

        alert.show();

    }*/

    public void conectionss(View view)
    {
        Intent intent = new Intent(SendingSMS.this,ConnectFriends.class);
        startActivity(intent);
    }
    public void makesCallings(View view)
    {
        Intent intent = new Intent(SendingSMS.this,SoftSimHome.class);
        startActivity(intent);
    }

}
