package com.example.lenovo.softsimapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Help extends AppCompatActivity {


    WebView myWebView;

    String maruURL = "https://clientarea.maru.africa/cart.php?a=add&pid=24";
    String lastname="";String firstname="";String email="";String mobile="";String password="";String identity="";
    //String identity="";
    String apikey="";
    String helpURL = "https://api.whatsapp.com/send?phone=27659204842";
    //https://api.whatsapp.com/send?phone=27659204842
    ProgressDialog progressDialog;
    String phones = "";

    Context context = null;

    double valuD=0;
    double amt =0;
    String result = "";
    private String LOG_TAG = "XML";
    private int UpdateFlag = 0;
    String Name="";
    String Range ="";
    ClientDB clientDB;
    Cursor cursor;
    String myResponse = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        progressDialog  = new ProgressDialog(Help.this);

        progressDialog.setTitle("Directing page...");
        progressDialog.setMessage("Please wait while we load our help site");
        progressDialog.show();
        clientDB = new ClientDB(this);
        myWebView = (WebView) findViewById(R.id.activity_main_webview);
        // WebSettings webSettings = myWebView.getSettings();

        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(helpURL)));

       /** AsyncHttpClient asycnHttpClient = new AsyncHttpClient(true, 80, 443);
        // AsyncHttpClient client = new AsyncHttpClient();
        asycnHttpClient.get(helpURL, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                progressDialog.dismiss();

                myWebView.loadUrl(helpURL);

                /**  AlertDialog.Builder builder = new AlertDialog.Builder(HelpLink.this);

                 builder.create();
                 builder.setTitle("Sending sms...");
                 builder.setMessage("Your SMS has been sent to: "+textPhoneNo.getText().toString());
                 builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub


                }
                });

                 AlertDialog alert = builder.create();

                 alert.show();

            }*/

            //@Override
            /**public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                progressDialog.dismiss();

                AlertDialog.Builder builder = new AlertDialog.Builder(Help.this);

                 builder.create();
                 builder.setTitle("Failed to load our helping page");
                 builder.setMessage("Please make sure you have fast internet connection and try again");
                 builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub


                }
                });

                 AlertDialog alert = builder.create();

                 alert.show();
            }


        });

        //myWebView.setWebViewClient(new WebViewClient());*/


    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.friendsmenu,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //searchView = (SearchView)item.getActionView();
        //View itemAction = item.getActionView();
        //noinspection SimplifiableIfStatement

        if (id == R.id.action_addcontact) {

            Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            startActivity(intent);
            return true;
        } else if (id == R.id.topup) {

            Intent intent = new Intent(Help.this, TopUp.class);
            startActivity(intent);

            // topup();

            return true;
        } else if (id == R.id.history) {
            Intent intent = new Intent(Help.this, CallHistory.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.Aboutus) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.maru.africa")));
            Intent intent = new Intent(Help.this, AboutUs.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.Help) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maru.bitrix24.com/online/clientchannel")));
            //https://maru.bitrix24.com/online/clientchannel

            Intent intent = new Intent(Help.this, Help.class);
            startActivity(intent);

            return true;
        } else if (id == R.id.chechbalance) {
            //checkBalance();

            progressDialog = new ProgressDialog(Help.this);

            progressDialog.setTitle("Checking your balance");
            progressDialog.setMessage("Please wait...");
            progressDialog.show();

            // https://greydotapi.me/?k=8a7758a8ddb69b417375&do=5
            cursor = clientDB.getData();


           /** if (cursor.moveToFirst()) {

                firstname = cursor.getString(1);
                lastname = cursor.getString(2);
                identity = cursor.getString(3);
                password = cursor.getString(4);
                email = cursor.getString(5);
                mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);
                apikey = cursor.getString(7);


            }*/
            //526c915430f835fa19c1   1ea9a91f6f53558d9203 //526c915430f835fa19c1
            String smsURL = "https://greydotapi.me/?k=" + cursor.getString(7) + "&do=" + 5;

            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
                    .url(smsURL)
                    .build();


            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    call.cancel();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {

                    myResponse = response.body().string();

                    Help.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            //txtString.setText(myResponse);


                        }
                    });


                }
            });

            try {

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser parser = factory.newPullParser();
                parser.setInput(new StringReader(myResponse));
                int eventType = parser.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {

                    if (eventType == XmlPullParser.START_TAG) {

                        String name = parser.getName();
                        if (name.equals("query_result")) {

                            String ref = parser.getAttributeValue(null, "ref");
                            Log.d(LOG_TAG, "ref:" + ref);

                            if (parser.next() == XmlPullParser.TEXT) {
                                String UpdateFlag = parser.getText();
                                Log.d(LOG_TAG, "query_result:" + UpdateFlag);
                            }


                        } else if (name.equals("dots")) {

                            if (parser.next() == XmlPullParser.TEXT) {
                                Name = parser.getText();
                                Log.d(LOG_TAG, "dots: " + Name);

                                valuD = Double.valueOf(Name.toString());
                                amt = valuD / 10;

                                result = String.format("%.2f", amt);

                            }
                        } else if (name.equals("status")) {

                            if (parser.next() == XmlPullParser.TEXT) {
                                Range = parser.getText();
                                Log.d(LOG_TAG, "status:" + Range);
                                if (Range.equals("Success")) {

                                } else {
                                    // Toast.makeText(this,"Error loading up",Toast.LENGTH_SHORT).show();
                                }
                            }
                        }


                    } else if (eventType == XmlPullParser.END_TAG) {


                    }
                    eventType = parser.next();


                }


            } catch (Exception e) {
                Log.d(LOG_TAG, "Error in ParseXML()", e);
            }

            AsyncHttpClient asycnHttpClient = new AsyncHttpClient(true, 90, 443);
            // AsyncHttpClient client = new AsyncHttpClient();
            asycnHttpClient.get(smsURL, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody) {

                    SoftSimHome softSimHome = new SoftSimHome();
                    String Helpdate = SoftSimHome.SaveDate();
                    progressDialog.dismiss();


                    AlertDialog.Builder builder = new AlertDialog.Builder(Help.this);

                    builder.create();
                    builder.setTitle("SoftSIM Balance");
                    builder.setMessage("Your balance is R " + result);
                    builder.setMessage("Date: " + Helpdate + "\n---------------------------------------------------" + "\nAirtime R"
                            + result);
                    builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub


                        }
                    });

                    builder.setNegativeButton("SMS", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            Intent intent = new Intent(Help.this, SendingSMS.class);
                            intent.putExtra("phone", phones);
                            startActivity(intent);

                        }
                    });

                    builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub
                            Intent intent = new Intent(Help.this, SoftSimHome.class);
                            startActivity(intent);

                        }
                    });

                    builder.setNeutralButton("TOP UP", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub

                            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
                            Intent intent = new Intent(Help.this, TopUp.class);
                            startActivity(intent);
                        }
                    });
                    AlertDialog alert = builder.create();

                    alert.show();

                }

                @Override
                public void onFailure(int statusCode, cz.msebera.android.httpclient.Header[] headers, byte[] responseBody, Throwable error) {

                    progressDialog.dismiss();

                    AlertDialog.Builder builder = new AlertDialog.Builder(Help.this);

                    builder.create();
                    builder.setTitle("Failed to check your balance");
                    builder.setMessage("Please check your internet connection and try again");
                    builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // TODO Auto-generated method stub


                        }
                    });

                    AlertDialog alert = builder.create();

                    alert.show();
                }


            });


            return true;


        }
        return super.onOptionsItemSelected(item);
    }

    public void sendsms(View view)
    {
        Intent intent = new Intent(Help.this,SendingSMS.class);
        intent.putExtra("phone",phones);
        startActivity(intent);
    }
    public void makesCallings(View view)
    {
        Intent intent = new Intent(Help.this,SoftSimHome.class);
        startActivity(intent);
    }
    public void conectionss(View view)
    {
        Intent intent = new Intent(Help.this,ConnectFriends.class);
        startActivity(intent);
    }



}

