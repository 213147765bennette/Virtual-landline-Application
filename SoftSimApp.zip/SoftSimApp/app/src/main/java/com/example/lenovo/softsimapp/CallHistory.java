package com.example.lenovo.softsimapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CallHistory extends AppCompatActivity {
ListView listview;
    List<String> mylist;
    String[] myStringarray;
    ImageView imageView;

    int pos = 0;
    //public static ArrayList<Integer> type = new ArrayList<Integer>();

    double valuD=0;
    double amt =0;
    String result = "";
    String myResponse = "";
    private String LOG_TAG = "XML";
    private int UpdateFlag = 0;
    String Name="";
    String Range ="";
    public String url= "";
    Cursor cursor;
    String phones ="";
    String timetaken = "";
    String description="";
    String fromWho="";
    String toWho="";
    String duration="";
    String countryDate="";
    String apikey = "";
    int type = 0;
    ArrayAdapter<String>adapter;
    Cursor historyCursor;
    String lastname="";String firstname="";String email="";String mobile="";String password="";String identity="";
    ClientDB clientDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_history);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setIcon(R.mipmap.ic_launcher);

        clientDB = new ClientDB(this);
        imageView = (ImageView) findViewById(R.id.imageView);
        listview = (ListView) findViewById(R.id.listview);
        historyCursor = clientDB.getCalls();
        StringBuffer sb = new StringBuffer();
        String callsHistory = "";

        int count = 0;
        //type = new ArrayList<Integer>();

        mylist = new ArrayList<String>();

        while(historyCursor.moveToNext()) {

            //Long time, String description, String from, String to, String duration, String cc, int type
            //int DBid = cursor.getInt(0);

           // clientDB.insertReport(System.currentTimeMillis(), description,  from,  to, type);

            timetaken = historyCursor.getString(0);
            description = historyCursor.getString(1);
            fromWho = historyCursor.getString(2);
            toWho = historyCursor.getString(3);
            type = historyCursor.getInt(4);

            if(fromWho==null)
            {
                sb.append("\nFrom:  " + "Unknown" + "\nTo:  " + toWho
                        +"\nDescription:  " +description + " \nTime:  " + timetaken);

                sb.append("\n                            ");
                //callsHistory = sb.toString();
            }else
                {
                    //sb.append("Call Details :");
                    sb.append("\nFrom:  " + fromWho + "\nTo:  " + toWho +"\nDescription:  " +description + " \nTime:  " + timetaken);

                    sb.append("\n                            ");

                }
            //sb.append("Call Details :");

            callsHistory = sb.toString();

            count++;


        }
        mylist.add(callsHistory);


       // myStringarray = new String[]{callsHistory};



        //NOTIFY IF CALL LOG IS EMPTY
        if(count==0)
            Toast.makeText(this,"Call history is empty", Toast.LENGTH_LONG).show();

        //String[] myValue = {callsHistory};
        //mylist.add(myValue);

        //Integer[] intID = {R.drawable.ic_action_incomming,R.drawable.ic_action_missed,R.drawable.ic_action_outgoing};

        //HistoryAdapter historyAdapter = new HistoryAdapter(this, (ArrayList<String>) mylist,intID);

        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,mylist);


        listview.setAdapter(adapter);

       /** listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {

                AlertDialog.Builder builder = new AlertDialog.Builder(CallHistory.this);

                builder.create();
                builder.setTitle("Delete log");
                builder.setMessage("Dou you want to delete");
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // TODO Auto-generated method stub


                        adapter.remove(mylist.get(position));

                        adapter.notifyDataSetChanged();

                    }
                });

                AlertDialog alert = builder.create();

                alert.show();
            }


        });  */

        }


    android.support.v7.widget.SearchView searchViewAction = null;
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_menu,menu);





        return true;
    }

    //private static boolean trSearch = false;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //searchView = (SearchView)item.getActionView();
        //View itemAction = item.getActionView();
        //noinspection SimplifiableIfStatement

        if (id == R.id.action_addcontact) {

            Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
            intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
            startActivity(intent);
            return true;
        }
        else  if (id == R.id.chechbalance) {
            //checkBalance();
            return true;
        }else  if (id == R.id.topup) {

            Intent intent = new Intent(CallHistory.this,TopUp.class);
            startActivity(intent);

            // topup();

            return true;
        }else  if (id == R.id.history) {
            Intent intent = new Intent(CallHistory.this,CallHistory.class);
            startActivity(intent);
            return true;
        }else  if (id == R.id.ClientDetails) {

            cursor = clientDB.getData();


            if(cursor.moveToFirst())
            {

                //int DBid = cursor.getInt(0);
                firstname = cursor.getString(1);
                lastname = cursor.getString(2);
                identity = cursor.getString(3);
                password = cursor.getString(4);
                email = cursor.getString(5);
                mobile = cursor.getString(6);
                //password = cursor.getString(5);
                //identity = cursor.getString(6);
                apikey = cursor.getString(7);


                //int DBid = cursor.getInt(0);
                /** firstname = cursor.getString(1);
                 lastname = cursor.getString(2);
                 email = cursor.getString(3);
                 mobile = cursor.getString(4);
                 //password = cursor.getString(5);
                 //identity = cursor.getString(6);
                 apikey = cursor.getString(5);*/

                // String name,String surname,String username,String password,String email,String phone ,String clientApi

                /**String firstname = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_NAME));
                 String lastname = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_SURNAME));
                 String email = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_EMAIL));
                 String mobile = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_PHONE));
                 String password = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_PASSWORD));
                 String identity = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_PASSWORD));
                 String apikey = cursor.getString(cursor.getColumnIndex(CLIENT_COLUMN_APPKEY));
                 */

            }
            AlertDialog.Builder builder = new AlertDialog.Builder(CallHistory.this);

            builder.create();
            builder.setTitle("Client details");
            builder.setMessage("Fisrt name: "+firstname+"\nLast name: "+lastname+"\nEmail: "+email+"\nMobile: "
                    +mobile+"\nPassword: " +password+" "+"\nIdentity: " +identity+" "+"\nApi Key: " + apikey);
            builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // TODO Auto-generated method stub


                }
            });

            AlertDialog alert = builder.create();

            alert.show();

            return true;
        }else  if (id == R.id.Aboutus) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.maru.africa")));
            Intent intent = new Intent(CallHistory.this,AboutUs.class);
            startActivity(intent);
            return true;
        }else  if (id == R.id.Help) {

            //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://maru.bitrix24.com/online/clientchannel")));
            //https://maru.bitrix24.com/online/clientchannel

            Intent intent = new Intent(CallHistory.this,Help.class);
            startActivity(intent);

            return true;
        }


        return super.onOptionsItemSelected(item);
    }



    public void conectionss(View view)
    {
        Intent intent = new Intent(CallHistory.this,ConnectFriends.class);
        startActivity(intent);
    }
    public void makesCallings(View view)
    {
        Intent intent = new Intent(CallHistory.this,SoftSimHome.class);
        startActivity(intent);
    }

    public void sendsms(View view)
    {
        Intent intent = new Intent(CallHistory.this,SendingSMS.class);
        intent.putExtra("phone",phones);
        startActivity(intent);
    }

    public static String SaveDate() {

        String Mydate = "";

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/M/d HH:mm:ss");
        Mydate = sdf.format(date);

        return  Mydate;
    }


   /** void run() throws IOException {




        String mykey = apikey;

        //1ea9a91f6f53558d9203
        //url = "https://greydotapi.me/?k=1ea9a91f6f53558d9203"+"&do=5";
        Uri.Builder builder = new Uri.Builder();
        builder.scheme("https")
                .authority("greydotapi.me")
                .appendQueryParameter("k", "526c915430f835fa19c1")
                .appendQueryParameter("do", "5");
        url = builder.build().toString();


        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                myResponse  = response.body().string();

                CallHistory.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        //txtString.setText(myResponse);


                    }
                });


            }
        });


    }*/

    public void ParseXML(String xmlString){

        try {

            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader(xmlString));
            int eventType = parser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT){

                if(eventType== XmlPullParser.START_TAG){

                    String name = parser.getName();
                    if(name.equals("query_result")){

                        String ref = parser.getAttributeValue(null,"ref");
                        Log.d(LOG_TAG,"ref:" + ref);

                        if(parser.next() == XmlPullParser.TEXT) {
                            String UpdateFlag = parser.getText();
                            Log.d(LOG_TAG,"query_result:" + UpdateFlag);
                        }


                    }else if(name.equals("dots")) {

                        if(parser.next() == XmlPullParser.TEXT) {
                            Name = parser.getText();
                            Log.d(LOG_TAG,"dots: " + Name);

                            valuD= Double.valueOf(Name.toString());
                            amt = valuD/10;

                            result = String.format("%.2f", amt);

                        }
                    }else if(name.equals("status")) {

                        if(parser.next() == XmlPullParser.TEXT) {
                            Range = parser.getText();
                            Log.d(LOG_TAG,"status:" + Range);
                            if(Range.equals("Success"))
                            {
                                //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.marusip.com/?pan=login")));
                            }else
                            {
                                Toast.makeText(this,"Error loading up",Toast.LENGTH_SHORT).show();
                            }
                        }
                    }


                }else if(eventType== XmlPullParser.END_TAG){


                }
                eventType = parser.next();


            }



        }catch (Exception e){
            Log.d(LOG_TAG,"Error in ParseXML()",e);
        }

    }
   /** public void checkBalance()
    {
        int duration = Toast.LENGTH_SHORT;

        String date = SaveDate();

        // double db = (Double.parseDouble(Name.toString()));




        // String.format("%d %.2f", amt);
        ParseXML(myResponse);

        AlertDialog.Builder builder = new AlertDialog.Builder(CallHistory.this);

        builder.create();
        builder.setTitle("SoftSIM Current balance");
        builder.setMessage("Date: " +date +"\n---------------------------------------------------"+"\nAirtime R"
                +result +"\nStatus: " + Range);
        builder.setNegativeButton("SMS", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(CallHistory.this,SendingSMS.class);
                intent.putExtra("phone",phones);
                startActivity(intent);

            }
        });

        builder.setPositiveButton("CALL", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                //Intent intent = new Intent(SoftSimHome.this,SoftSimHome.class);
                //startActivity(intent);

            }
        });

        builder.setNeutralButton("TOP UP", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub

                //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(maruURL)));
                Intent intent = new Intent(CallHistory.this,TopUp.class);
                startActivity(intent);
            }
        });



        AlertDialog alert = builder.create();

        alert.show();

    }*/



}








