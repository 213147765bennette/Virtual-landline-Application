package com.example.lenovo.softsimapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class SoftSimSignup extends AppCompatActivity {
    Button btnReg;
    EditText edtFirst,edtLast, edtUser, edtPass, edtConfPass, edtEmail,edtMobile,edtCode;

    private long id;//primary key
    private String firstname;
    private String surname;
    private String mobile;
    private String email;
    static Context context;

   // private FirebaseAuth.AuthStateListener mAuthListener;
    //private FirebaseAuth mAuth;

    public ArrayList<String> myList = new ArrayList<String>();

    String text ="Client information was SAVED into database";
    String text2 ="Client information was NOT into database";
    int duration = Toast.LENGTH_SHORT;
    Toast toast;
    ClientDB clientDB;
    String testingAPI ="686e669fbef4f969515c";
    //GET THEM FROM SIGNUP XML STRING RETURNED
   // private String apikey;
    private String username;
    private String password;
    private String dbID;
    //DataBaseAdapter dataBaseAdapter;
    String Range ="";
    String signupUrl = "";
    String Identity="";
    String Password ="";
    String Appkey = "";
    String myAndroidURL="";
    Person person;
    FileOutputStream fileOutputStream = null;
    String apikey="25c0f00d96451b2edf5e";
    String testURL = "https://greydotapi.me/?k=686e669fbef4f969515c&do=5";
    private String LOG_TAG = "XML";
    String myResponse = "";
    Intent intent;
    Button button10;
    ProgressDialog progressDialog;

    String userCode = "";

    String codeRecived = "";

    String codesent;

    String sendMobileNumber = "";

    String ADMINSIGNUP = "1ea9a91f6f53558d9203";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soft_sim_signup);

        Intent intent = getIntent();
        sendMobileNumber = (String) intent.getSerializableExtra("mobile");

        //context = getApplicationContext();

        edtFirst= (EditText) findViewById(R.id.edtfirstname);
        edtLast= (EditText) findViewById(R.id.edtlastname);

        edtEmail= (EditText) findViewById(R.id.edtEmail);
        edtMobile= (EditText) findViewById(R.id.edtMobile);


        //edtCode=(EditText)findViewById(R.id.editText4);


        edtMobile.setText(sendMobileNumber);
        firstname = edtFirst.getText().toString();
        surname = edtLast.getText().toString();
        mobile = edtMobile.getText().toString();
        email = edtEmail.getText().toString();

        //Initialization of Register Button
        //btnReg=(Button)findViewById(R.id.button1);
        button10= (Button) findViewById(R.id.button10);

        button10.setVisibility(View.INVISIBLE);





    }






    public void run()throws IOException
    {

        URL url = new URL("https://greydotapi.me/");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setReadTimeout(10000);
        conn.setConnectTimeout(15000);;
        conn.setRequestMethod("POST");
        conn.setDoInput(true);
        conn.setDoOutput(true);

        // builder.scheme("https")
        // .authority("greydotapi.me")


        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("k", "1ea9a91f6f53558d9203")
                .appendQueryParameter("do", "19")
                .appendQueryParameter("par1",edtLast.getText().toString())
                .appendQueryParameter("par2",edtFirst.getText().toString())
                .appendQueryParameter("par3", edtEmail.getText().toString())
                .appendQueryParameter("par4", edtMobile.getText().toString())
                .appendQueryParameter("par5", "553042")
                .appendQueryParameter("par7", "0")
                .appendQueryParameter("par8", "1");
        myAndroidURL = builder.build().toString();

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(myAndroidURL)
                .build();


        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                myResponse = response.body().string();

                SoftSimSignup.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        //txtString.setText(myResponse);

                        ParseXML(myResponse);

                    }
                });


            }
        });
    }

    public void ParseXML(String xmlString) {



        try {

            XmlPullParserFactory  factory = XmlPullParserFactory.newInstance();
            XmlPullParser   parser = factory.newPullParser();

            factory.setNamespaceAware(true);
            parser.setInput(new StringReader(xmlString));
            int eventType = parser.getEventType();

            /**            <query>
             <query_result>
             <status>Success</status>
             <function>SignUp</function>
             <signup_status>Registered</signup_status>
             <identity>25911190287</identity>
             <password>0770647750</password>
             <appkey>d7223431568ffd58c709</appkey>
             </query_result>
             <query_status>DONE</query_status>
             <query_code>D0019</query_code>
             </query>
             */

            while (eventType != XmlPullParser.END_DOCUMENT) {

                if (eventType == XmlPullParser.START_TAG) {

                    String name = parser.getName();
                    if (name.equals("query_result")) {


                        String ref = parser.getAttributeValue(null, "ref");
                        Log.d(LOG_TAG, "ref:" + ref);

                        if (parser.next() == XmlPullParser.TEXT) {
                            String UpdateFlag = parser.getText();
                            Log.d(LOG_TAG, "query_result:" + UpdateFlag);

                        }
                    } else if (name.equals("identity")) {

                        if (parser.next() == XmlPullParser.TEXT) {
                            Identity = parser.getText();
                            Log.d(LOG_TAG, "identity: " + Identity);


                        }
                    } else if (name.equals("password")) {

                        if (parser.next() == XmlPullParser.TEXT) {
                            Password = parser.getText();
                            Log.d(LOG_TAG, "password:" + Password);

                            //getXMLdata();
                        }
                    } else if (name.equals("appkey")) {

                        if (parser.next() == XmlPullParser.TEXT) {
                            Appkey = parser.getText();
                            Log.d(LOG_TAG, "appkey: " + Appkey);

                            /**clientDB.insertClient(edtFirst.getText().toString(),edtLast.getText().toString(),
                                    Identity,Password,edtEmail.getText().toString(),
                                    edtMobile.getText().toString(),Appkey);
*/
                            //getXMLdata();

                        }
                    }else if (name.equals("status")) {

                        if (parser.next() == XmlPullParser.TEXT) {
                            Range = parser.getText();
                            Log.d(LOG_TAG, "status: " + Range);

                            if (Range.equals("Success")) {

                               // Toast.makeText(this, "Your details a secured now", Toast.LENGTH_SHORT).show();

                            } else {

                               // Toast.makeText(this, "Error loading up", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }


                } else if (eventType == XmlPullParser.END_TAG) {


                }
                eventType = parser.next();


            }


        } catch (Exception e) {
            Log.d(LOG_TAG, "Error in ParseXML()", e);
        }

    }

    /**public void getXMLdata() {
        AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimSignup.this);

        builder.create();
        builder.setTitle("Client XML info");
        builder.setMessage("Password: " + Password + "\nIdentity: " + Identity + "\nApi Key: " + Appkey);
        builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub


            }
        });

        AlertDialog alert = builder.create();

        alert.show();

    }*/



   public void signupNow(View view) {


       progressDialog  = new ProgressDialog(SoftSimSignup.this);
       progressDialog.setTitle("Signing up...");
       progressDialog.setMessage("Please wait while we verify your details");
       progressDialog.show();


       try {
           run();
       } catch (IOException e) {
           e.printStackTrace();
       }

       if (edtFirst.getText().toString().length() == 0) {
            edtFirst.setError("First name not entered");
            edtFirst.requestFocus();
        }
        if (edtLast.getText().toString().length() == 0) {
            edtLast.setError("Last name not entered");
            edtLast.requestFocus();
        }
        if (edtMobile.getText().toString().length() < 10 || edtMobile.getText().toString().length() > 10) {
            edtMobile.setError("Mobile number must be in a correct format");
            edtMobile.requestFocus();
        }

        if (!edtEmail.getText().toString().contains("@")) {
            edtEmail.setError("Enter correct email");
            edtEmail.requestFocus();
        } else {
            //admin key 1ea9a91f6f53558d9203
            //admin referal key 553042     http://175266.1no.me

            //username = edtUser.getText().toString();
            //password = edtPass.getText().toString();
            // mobile =edtMobile.getText().toString();

           /** apikey = apikey+" ";
            // username = username + " ";

            try {
                fileOutputStream = openFileOutput("clientFile.txt",Context.MODE_PRIVATE);

                fileOutputStream.write(apikey.getBytes());
                //fileOutputStream.write(username.getBytes());
                //fileOutputStream.write(password.getBytes());
                fileOutputStream.write(mobile.getBytes());


            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
          */




            //Toast.makeText(this,"Data save succesfully",Toast.LENGTH_LONG).show();
            //clientDB = new ClientDB(getApplicationContext());
            // clientDB.insertContact(edtFirst.getText().toString(),edtLast.getText().toString(),edtUser.getText().toString(),
            // edtPass.getText().toString(),edtEmail.getText().toString(),edtMobile.getText().toString());
            //person = new Person(firstname,surname,mobile,email,username,password);


            signupUrl = "https://greydotapi.me/?k=1ea9a91f6f53558d9203&do=19\n" +
                    "&par1=" + edtFirst.getText().toString() + "&par2=" + edtLast.getText().toString()
                    + "&par3=" + edtEmail.getText().toString() + "\n" +
                    "&par4=" + edtMobile.getText().toString() + "&par5=553042&par7=0&par8=1";

            //clientDB.insertClient(edtFirst.getText().toString(),edtLast.getText().toString()
                    //,edtEmail.getText().toString(),edtMobile.getText().toString(),Appkey);


           if(Identity!=null&&Password!=null&Appkey!=null)
            {
               // Toast.makeText(this, "Your details a secured now", Toast.LENGTH_SHORT).show();

            }else
                {
                    Toast.makeText(this, "No AppKey,Password and Identity found", Toast.LENGTH_SHORT).show();
                }


            //String name,String surname,String username,String password,String email,String phone ,String clientApi


        }
       AsyncHttpClient client = new AsyncHttpClient(true,90, 443);
       //AsyncHttpClient client = new AsyncHttpClient();
       client.get(signupUrl,  new AsyncHttpResponseHandler() {
           @Override
           public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {

               progressDialog.dismiss();

               button10.setVisibility(View.VISIBLE);

               /** AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimSignup.this);

                builder.create();
                builder.setTitle("You have Successfully Signed Up");
                builder.setMessage("Thank you for Choosing Maru Africa");
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

               @Override
               public void onClick(DialogInterface dialog, int which) {
               // TODO Auto-generated method stub


               }
               });

                AlertDialog alert = builder.create();

                alert.show();*/

           }

           @Override
           public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {

               progressDialog.dismiss();

               AlertDialog.Builder builder = new AlertDialog.Builder(SoftSimSignup.this);

                builder.create();
                builder.setTitle("Failed to Sign Up");
                builder.setMessage("Please check your internet connection and try Again");
                builder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {

               @Override
               public void onClick(DialogInterface dialog, int which) {
               // TODO Auto-generated method stub

               //Intent intent = new Intent(SoftSimSignup.this,SoftSimSignup.class);
               //startActivity(intent);

               }
               });

                AlertDialog alert = builder.create();

                 alert.show();

           }
       });

       //startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(signupUrl)));

      // startActivity(intent);

   }

   public void confirm(View view)
   {
       clientDB = new ClientDB(this);
       clientDB.insertClient(edtFirst.getText().toString(), edtLast.getText().toString(),
               Identity, Password, edtEmail.getText().toString(),
               edtMobile.getText().toString(), Appkey);

       Intent intent = new Intent(SoftSimSignup.this, SoftSimHome.class);
       startActivity(intent);

   }


}
